/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author juanc
 */

import dao.UsuarioDAO;
import modelo.Usuario;
import vista.UsuariosView;

import javax.swing.*;
import java.util.List;

public class UsuarioController {

    private final UsuariosView vista;
    private final UsuarioDAO usuarioDAO;

    public UsuarioController(UsuariosView vista) {
        this.vista = vista;
        this.usuarioDAO = new UsuarioDAO();

        configurarEventos();
        cargarUsuarios();
    }

    // =========================================
    // EVENTOS
    // =========================================
    private void configurarEventos() {

        vista.getBtnNuevo().addActionListener(e -> nuevoUsuario());

        vista.getBtnLimpiar().addActionListener(e -> nuevoUsuario());

        vista.getBtnGuardar().addActionListener(e -> guardarUsuario());

        vista.getBtnActualizar().addActionListener(e -> actualizarUsuario());

        vista.getBtnEliminar().addActionListener(e -> eliminarUsuario());

        vista.getTablaUsuarios().getSelectionModel()
                .addListSelectionListener(e -> {
                    if (!e.getValueIsAdjusting()) {
                        seleccionarUsuario();
                    }
                });
    }

    // =========================================
    // CARGAR USUARIOS
    // =========================================
    private void cargarUsuarios() {

        vista.getModeloTabla().setRowCount(0);

        List<Usuario> usuarios = usuarioDAO.listarUsuarios();

        for (Usuario usuario : usuarios) {

            vista.getModeloTabla().addRow(new Object[]{
                usuario.getIdUsuario(),
                usuario.getNombre(),
                usuario.getUsuario(),
                usuario.getRol(),
                usuario.getEstado() == 1 ? "ACTIVO" : "INACTIVO"
            });
        }

        vista.getLblInfo().setText(
                "Usuarios registrados: " + usuarios.size()
        );
    }

    // =========================================
    // SELECCIONAR USUARIO
    // =========================================
    private void seleccionarUsuario() {

        int fila = vista.getTablaUsuarios().getSelectedRow();

        if (fila == -1) {
            return;
        }

        vista.getTxtId().setText(
                vista.getModeloTabla().getValueAt(fila, 0).toString()
        );

        vista.getTxtNombre().setText(
                vista.getModeloTabla().getValueAt(fila, 1).toString()
        );

        vista.getTxtUsuario().setText(
                vista.getModeloTabla().getValueAt(fila, 2).toString()
        );

        vista.getTxtPassword().setText("");

        vista.getCmbRol().setSelectedItem(
                vista.getModeloTabla().getValueAt(fila, 3).toString()
        );

        vista.getCmbEstado().setSelectedItem(
                vista.getModeloTabla().getValueAt(fila, 4).toString()
        );

        vista.getLblInfo().setText(
                "Usuario seleccionado. Puedes actualizar sus datos."
        );
    }

    // =========================================
    // NUEVO USUARIO
    // =========================================
    private void nuevoUsuario() {

        vista.limpiarFormulario();

        vista.getLblInfo().setText(
                "Formulario listo para registrar un usuario."
        );

        vista.getTxtNombre().requestFocus();
    }

    // =========================================
    // GUARDAR USUARIO
    // =========================================
    private void guardarUsuario() {

        String nombre = vista.getTxtNombre().getText().trim();
        String usuario = vista.getTxtUsuario().getText().trim();
        String password = new String(
                vista.getTxtPassword().getPassword()
        );

        String rol = vista.getCmbRol().getSelectedItem().toString();
        int estado = vista.getCmbEstado()
                .getSelectedItem().toString().equals("ACTIVO") ? 1 : 0;

        if (nombre.isEmpty() || usuario.isEmpty() || password.isEmpty()) {
            vista.mostrarMensaje(
                    "Completa el nombre, usuario y contraseña."
            );
            return;
        }

        if (usuarioDAO.existeUsuario(usuario, 0)) {
            vista.mostrarMensaje(
                    "Ya existe una cuenta con ese nombre de usuario."
            );
            return;
        }

        Usuario nuevo = new Usuario(
                0, nombre, usuario, password, rol, estado
        );

        if (usuarioDAO.registrarUsuario(nuevo)) {

            vista.mostrarMensaje("Usuario registrado correctamente.");

            nuevoUsuario();
            cargarUsuarios();

        } else {
            vista.mostrarMensaje("No fue posible registrar el usuario.");
        }
    }

    // =========================================
    // ACTUALIZAR USUARIO
    // =========================================
    private void actualizarUsuario() {

        if (vista.getTxtId().getText().trim().isEmpty()) {
            vista.mostrarMensaje(
                    "Selecciona un usuario de la tabla para actualizarlo."
            );
            return;
        }

        int id = Integer.parseInt(vista.getTxtId().getText());

        String nombre = vista.getTxtNombre().getText().trim();
        String usuario = vista.getTxtUsuario().getText().trim();
        String password = new String(
                vista.getTxtPassword().getPassword()
        );

        String rol = vista.getCmbRol().getSelectedItem().toString();
        int estado = vista.getCmbEstado()
                .getSelectedItem().toString().equals("ACTIVO") ? 1 : 0;

        if (nombre.isEmpty() || usuario.isEmpty()) {
            vista.mostrarMensaje(
                    "El nombre y el usuario son obligatorios."
            );
            return;
        }

        if (usuarioDAO.existeUsuario(usuario, id)) {
            vista.mostrarMensaje(
                    "Ese nombre de usuario ya está registrado."
            );
            return;
        }

        // Evitar dejar el sistema sin administradores activos.
        if (!puedeModificarAdministrador(id, rol, estado)) {
            return;
        }

        if (password.isEmpty()) {
            vista.mostrarMensaje(
                    "Para actualizar este usuario debes ingresar su contraseña."
            );
            return;
        }

        Usuario actualizado = new Usuario(
                id, nombre, usuario, password, rol, estado
        );

        if (usuarioDAO.actualizarUsuario(actualizado)) {

            vista.mostrarMensaje("Usuario actualizado correctamente.");

            nuevoUsuario();
            cargarUsuarios();

        } else {
            vista.mostrarMensaje("No fue posible actualizar el usuario.");
        }
    }

    // =========================================
    // ELIMINAR USUARIO
    // =========================================
    private void eliminarUsuario() {

        if (vista.getTxtId().getText().trim().isEmpty()) {
            vista.mostrarMensaje(
                    "Selecciona un usuario para eliminarlo."
            );
            return;
        }

        int id = Integer.parseInt(vista.getTxtId().getText());

        int fila = vista.getTablaUsuarios().getSelectedRow();

        if (fila == -1) {
            return;
        }

        String rol = vista.getModeloTabla()
                .getValueAt(fila, 3).toString();

        String estado = vista.getModeloTabla()
                .getValueAt(fila, 4).toString();

        if (rol.equals("ADMIN") && estado.equals("ACTIVO")
                && usuarioDAO.contarAdministradoresActivos() <= 1) {

            vista.mostrarMensaje(
                    "No puedes eliminar al último administrador activo."
            );
            return;
        }

        int respuesta = vista.confirmar(
                "¿Estás seguro de eliminar este usuario?"
        );

        if (respuesta == JOptionPane.YES_OPTION) {

            if (usuarioDAO.eliminarUsuario(id)) {

                vista.mostrarMensaje("Usuario eliminado correctamente.");

                nuevoUsuario();
                cargarUsuarios();

            } else {
                vista.mostrarMensaje("No fue posible eliminar el usuario.");
            }
        }
    }

    // =========================================
    // PROTEGER ADMINISTRADORES
    // =========================================
    private boolean puedeModificarAdministrador(
            int id, String nuevoRol, int nuevoEstado) {

        int fila = vista.getTablaUsuarios().getSelectedRow();

        if (fila == -1) {
            return false;
        }

        String rolAnterior = vista.getModeloTabla()
                .getValueAt(fila, 3).toString();

        String estadoAnterior = vista.getModeloTabla()
                .getValueAt(fila, 4).toString();

        boolean eraAdminActivo = rolAnterior.equals("ADMIN")
                && estadoAnterior.equals("ACTIVO");

        boolean dejaDeSerAdminActivo = !nuevoRol.equals("ADMIN")
                || nuevoEstado == 0;

        if (eraAdminActivo && dejaDeSerAdminActivo
                && usuarioDAO.contarAdministradoresActivos() <= 1) {

            vista.mostrarMensaje(
                    "No puedes quitar o desactivar al último administrador activo."
            );
            return false;
        }

        return true;
    }
}
