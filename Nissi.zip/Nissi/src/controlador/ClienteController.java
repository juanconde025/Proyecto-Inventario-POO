/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author juanc
 */

import dao.ClienteDAO;
import modelo.Cliente;
import vista.ClientesView;

import javax.swing.*;
import java.util.List;

public class ClienteController {

    private final ClientesView vista;
    private final ClienteDAO dao;

    public ClienteController(ClientesView vista) {
        this.vista = vista;
        this.dao = new ClienteDAO();

        configurarEventos();
        cargarClientes();
    }

    private void configurarEventos() {

        vista.getBtnNuevo().addActionListener(e -> limpiar());

        vista.getBtnGuardar().addActionListener(e -> guardar());

        vista.getBtnActualizar().addActionListener(e -> actualizar());

        vista.getBtnEliminar().addActionListener(e -> eliminar());

        vista.getTabla().getSelectionModel()
                .addListSelectionListener(e -> {
                    if (!e.getValueIsAdjusting()) {
                        seleccionar();
                    }
                });
    }

    private void cargarClientes() {

        vista.getModelo().setRowCount(0);

        List<Cliente> clientes = dao.listarClientes();

        for (Cliente c : clientes) {
            vista.getModelo().addRow(new Object[]{
                c.getIdCliente(),
                c.getDocumento(),
                c.getNombre(),
                c.getTelefono(),
                c.getCorreo(),
                c.getEstado() == 1 ? "ACTIVO" : "INACTIVO"
            });
        }

        vista.getLblInfo().setText(
                "Clientes registrados: " + clientes.size()
        );
    }

    private void seleccionar() {

        int fila = vista.getTabla().getSelectedRow();

        if (fila < 0) {
            return;
        }

        vista.getTxtId().setText(
                vista.getModelo().getValueAt(fila, 0).toString()
        );
        vista.getTxtDocumento().setText(
                vista.getModelo().getValueAt(fila, 1).toString()
        );
        vista.getTxtNombre().setText(
                vista.getModelo().getValueAt(fila, 2).toString()
        );

        vista.getTxtTelefono().setText(
                valorCelda(fila, 3)
        );
        vista.getTxtCorreo().setText(
                valorCelda(fila, 4)
        );

        vista.getCmbEstado().setSelectedItem(
                vista.getModelo().getValueAt(fila, 5).toString()
        );

        // La dirección no está en la tabla, se consulta por ID.
        int id = Integer.parseInt(vista.getTxtId().getText());
        Cliente cliente = dao.buscarPorId(id);

        if (cliente != null) {
            vista.getTxtDireccion().setText(
                    cliente.getDireccion() == null
                    ? "" : cliente.getDireccion()
            );
        }
    }

    private String valorCelda(int fila, int columna) {
        Object valor = vista.getModelo().getValueAt(fila, columna);
        return valor == null ? "" : valor.toString();
    }

    private void guardar() {

        String documento = vista.getTxtDocumento().getText().trim();
        String nombre = vista.getTxtNombre().getText().trim();

        if (documento.isEmpty() || nombre.isEmpty()) {
            vista.mostrarMensaje(
                    "El documento y el nombre son obligatorios."
            );
            return;
        }

        if (dao.existeDocumento(documento, 0)) {
            vista.mostrarMensaje(
                    "Ya existe un cliente con ese documento."
            );
            return;
        }

        Cliente cliente = construirCliente(0);

        if (dao.registrarCliente(cliente)) {
            vista.mostrarMensaje("Cliente registrado correctamente.");
            limpiar();
            cargarClientes();
        } else {
            vista.mostrarMensaje("No se pudo registrar el cliente.");
        }
    }

    private void actualizar() {

        if (vista.getTxtId().getText().trim().isEmpty()) {
            vista.mostrarMensaje("Selecciona un cliente.");
            return;
        }

        int id = Integer.parseInt(vista.getTxtId().getText());

        String documento = vista.getTxtDocumento().getText().trim();
        String nombre = vista.getTxtNombre().getText().trim();

        if (documento.isEmpty() || nombre.isEmpty()) {
            vista.mostrarMensaje(
                    "El documento y el nombre son obligatorios."
            );
            return;
        }

        if (dao.existeDocumento(documento, id)) {
            vista.mostrarMensaje(
                    "Otro cliente ya tiene ese documento."
            );
            return;
        }

        Cliente cliente = construirCliente(id);

        if (dao.actualizarCliente(cliente)) {
            vista.mostrarMensaje("Cliente actualizado correctamente.");
            limpiar();
            cargarClientes();
        } else {
            vista.mostrarMensaje("No se pudo actualizar el cliente.");
        }
    }

    private void eliminar() {

        if (vista.getTxtId().getText().trim().isEmpty()) {
            vista.mostrarMensaje("Selecciona un cliente.");
            return;
        }

        int id = Integer.parseInt(vista.getTxtId().getText());

        if (vista.confirmar(
                "¿Deseas desactivar este cliente? Sus ventas se conservarán."
        ) != JOptionPane.YES_OPTION) {
            return;
        }

        if (dao.eliminarCliente(id)) {
            vista.mostrarMensaje("Cliente desactivado correctamente.");
            limpiar();
            cargarClientes();
        } else {
            vista.mostrarMensaje("No se pudo desactivar el cliente.");
        }
    }

    private Cliente construirCliente(int id) {

        int estado = vista.getCmbEstado()
                .getSelectedItem().toString().equals("ACTIVO") ? 1 : 0;

        return new Cliente(
                id,
                vista.getTxtDocumento().getText().trim(),
                vista.getTxtNombre().getText().trim(),
                vista.getTxtTelefono().getText().trim(),
                vista.getTxtCorreo().getText().trim(),
                vista.getTxtDireccion().getText().trim(),
                estado
        );
    }

    private void limpiar() {
        vista.limpiarFormulario();
        vista.getLblInfo().setText(
                "Formulario listo para registrar un cliente."
        );
    }
}

