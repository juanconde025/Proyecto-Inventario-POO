/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author juanc
 */

import dao.UsuarioDAO;
import modelo.Usuario;
import vista.LoginView;
import vista.MenuPrincipalView;

public class LoginController {

    private LoginView vista;
    private UsuarioDAO usuarioDAO;

    public LoginController(LoginView vista) {
        this.vista = vista;
        this.usuarioDAO = new UsuarioDAO();

        this.vista.getBtnIngresar().addActionListener(e -> iniciarSesion());
    }

    private void iniciarSesion() {

        String usuario = vista.getTxtUsuario().getText().trim();

        String password =
                new String(vista.getTxtPassword().getPassword());

        if (usuario.isEmpty() || password.isEmpty()) {

            vista.mostrarMensaje(
                    "Debe ingresar usuario y contraseña."
            );

            return;
        }

        Usuario usuarioEncontrado =
                usuarioDAO.iniciarSesion(usuario, password);

        if (usuarioEncontrado != null) {

            MenuPrincipalView menu =
                    new MenuPrincipalView(usuarioEncontrado);

            menu.setVisible(true);

            vista.dispose();

        } else {

            vista.mostrarMensaje(
                    "Usuario o contraseña incorrectos."
            );
        }
    }
}
