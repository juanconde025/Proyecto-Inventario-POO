/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author juanc
 */

import dao.ProductoDAO;
import modelo.Producto;
import vista.MenuPrincipalView;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class ProductoController {

    private MenuPrincipalView vista;
    private ProductoDAO productoDAO;

    public ProductoController(MenuPrincipalView vista) {

        this.vista = vista;
        this.productoDAO = new ProductoDAO();

        cargarProductos();

        vista.getBtnNuevo().addActionListener(e -> limpiarFormulario());

        vista.getBtnGuardar().addActionListener(e -> guardarProducto());

        vista.getBtnActualizar().addActionListener(e -> actualizarProducto());

        vista.getBtnEliminar().addActionListener(e -> eliminarProducto());

        vista.getBtnLimpiar().addActionListener(e -> limpiarFormulario());

        vista.getTablaProductos().getSelectionModel()
                .addListSelectionListener(e -> cargarSeleccion());
    }

    private void cargarProductos() {

        List<Producto> productos =
                productoDAO.listar();

        DefaultTableModel modelo =
                vista.getModeloTabla();

        modelo.setRowCount(0);

        for (Producto p : productos) {

            modelo.addRow(new Object[]{
                    p.getIdProducto(),
                    p.getCodigo(),
                    p.getNombre(),
                    p.getCategoria(),
                    p.getPrecio(),
                    p.getStock(),
                    p.getDescripcion()
            });
        }
    }

    private void guardarProducto() {

        try {

            Producto producto =
                    obtenerProductoFormulario();

            if (producto == null) {
                return;
            }

            if (productoDAO.insertar(producto)) {

                vista.mostrarMensaje(
                        "Producto registrado correctamente."
                );

                cargarProductos();
                limpiarFormulario();

            } else {

                vista.mostrarMensaje(
                        "No fue posible registrar el producto."
                );
            }

        } catch (Exception e) {

            vista.mostrarMensaje(
                    "Error: " + e.getMessage()
            );
        }
    }

    private void actualizarProducto() {

        int fila =
                vista.getTablaProductos().getSelectedRow();

        if (fila == -1) {

            vista.mostrarMensaje(
                    "Seleccione un producto de la tabla."
            );

            return;
        }

        try {

            Producto producto =
                    obtenerProductoFormulario();

            if (producto == null) {
                return;
            }

            int id =
                    Integer.parseInt(
                            vista.getTxtId().getText()
                    );

            producto.setIdProducto(id);

            if (productoDAO.actualizar(producto)) {

                vista.mostrarMensaje(
                        "Producto actualizado correctamente."
                );

                cargarProductos();
                limpiarFormulario();

            } else {

                vista.mostrarMensaje(
                        "No fue posible actualizar el producto."
                );
            }

        } catch (Exception e) {

            vista.mostrarMensaje(
                    "Error: " + e.getMessage()
            );
        }
    }

    private void eliminarProducto() {

        int fila =
                vista.getTablaProductos().getSelectedRow();

        if (fila == -1) {

            vista.mostrarMensaje(
                    "Seleccione un producto."
            );

            return;
        }

        int id =
                Integer.parseInt(
                        vista.getTxtId().getText()
                );

        int confirmacion =
                JOptionPane.showConfirmDialog(
                        vista,
                        "¿Desea eliminar este producto?",
                        "Confirmar eliminación",
                        JOptionPane.YES_NO_OPTION
                );

        if (confirmacion == JOptionPane.YES_OPTION) {

            if (productoDAO.eliminar(id)) {

                vista.mostrarMensaje(
                        "Producto eliminado correctamente."
                );

                cargarProductos();
                limpiarFormulario();

            } else {

                vista.mostrarMensaje(
                        "No fue posible eliminar el producto."
                );
            }
        }
    }

    private Producto obtenerProductoFormulario() {

        String codigo =
                vista.getTxtCodigo().getText().trim();

        String nombre =
                vista.getTxtNombre().getText().trim();

        String categoria =
                vista.getTxtCategoria().getText().trim();

        String precioTexto =
                vista.getTxtPrecio().getText().trim();

        String stockTexto =
                vista.getTxtStock().getText().trim();

        String descripcion =
                vista.getTxtDescripcion().getText().trim();

        if (codigo.isEmpty()
                || nombre.isEmpty()
                || categoria.isEmpty()
                || precioTexto.isEmpty()
                || stockTexto.isEmpty()) {

            vista.mostrarMensaje(
                    "Complete todos los campos obligatorios."
            );

            return null;
        }

        double precio;
        int stock;

        try {

            precio =
                    Double.parseDouble(precioTexto);

            stock =
                    Integer.parseInt(stockTexto);

        } catch (NumberFormatException e) {

            vista.mostrarMensaje(
                    "Precio y stock deben ser números válidos."
            );

            return null;
        }

        if (precio < 0 || stock < 0) {

            vista.mostrarMensaje(
                    "Precio y stock no pueden ser negativos."
            );

            return null;
        }

        Producto producto = new Producto();

        producto.setCodigo(codigo);
        producto.setNombre(nombre);
        producto.setCategoria(categoria);
        producto.setPrecio(precio);
        producto.setStock(stock);
        producto.setDescripcion(descripcion);
        producto.setEstado(1);

        return producto;
    }

    private void cargarSeleccion() {

        int fila =
                vista.getTablaProductos().getSelectedRow();

        if (fila == -1) {
            return;
        }

        vista.getTxtId().setText(
                vista.getModeloTabla()
                        .getValueAt(fila, 0).toString()
        );

        vista.getTxtCodigo().setText(
                vista.getModeloTabla()
                        .getValueAt(fila, 1).toString()
        );

        vista.getTxtNombre().setText(
                vista.getModeloTabla()
                        .getValueAt(fila, 2).toString()
        );

        vista.getTxtCategoria().setText(
                vista.getModeloTabla()
                        .getValueAt(fila, 3).toString()
        );

        vista.getTxtPrecio().setText(
                vista.getModeloTabla()
                        .getValueAt(fila, 4).toString()
        );

        vista.getTxtStock().setText(
                vista.getModeloTabla()
                        .getValueAt(fila, 5).toString()
        );

        Object descripcion =
                vista.getModeloTabla()
                        .getValueAt(fila, 6);

        vista.getTxtDescripcion().setText(
                descripcion == null
                        ? ""
                        : descripcion.toString()
        );
    }

    private void limpiarFormulario() {

        vista.getTxtId().setText("");
        vista.getTxtCodigo().setText("");
        vista.getTxtNombre().setText("");
        vista.getTxtCategoria().setText("");
        vista.getTxtPrecio().setText("");
        vista.getTxtStock().setText("");
        vista.getTxtDescripcion().setText("");

        vista.getTablaProductos().clearSelection();
    }
}
