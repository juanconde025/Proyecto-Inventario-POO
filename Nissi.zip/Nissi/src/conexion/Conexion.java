/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.Conexion to edit this template
 */
package conexion;

/**
 *
 * @author juanc
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Conexion {

    private static final String URL = "jdbc:sqlite:nissi_accesorios.db";

    public static Connection conectar() throws SQLException {

        Connection conexion = DriverManager.getConnection(URL);

        crearTablas(conexion);

        return conexion;
    }

    private static void crearTablas(Connection conexion) {

        try (Statement st = conexion.createStatement()) {

            // ============================================
            // TABLA USUARIOS
            // ============================================

            String sqlUsuarios = """
                    CREATE TABLE IF NOT EXISTS usuarios (
                        id_usuario INTEGER PRIMARY KEY AUTOINCREMENT,
                        nombre TEXT NOT NULL,
                        usuario TEXT NOT NULL UNIQUE,
                        password TEXT NOT NULL,
                        rol TEXT NOT NULL DEFAULT 'ADMIN',
                        estado INTEGER NOT NULL DEFAULT 1
                    )
                    """;

            st.execute(sqlUsuarios);

            // ============================================
            // TABLA PRODUCTOS
            // ============================================

            String sqlProductos = """
                    CREATE TABLE IF NOT EXISTS productos (
                        id_producto INTEGER PRIMARY KEY AUTOINCREMENT,
                        codigo TEXT NOT NULL UNIQUE,
                        nombre TEXT NOT NULL,
                        categoria TEXT NOT NULL,
                        precio REAL NOT NULL CHECK(precio >= 0),
                        stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0),
                        descripcion TEXT,
                        estado INTEGER NOT NULL DEFAULT 1
                    )
                    """;

            st.execute(sqlProductos);

            // ============================================
            // USUARIO ADMINISTRADOR
            // ============================================

            String sqlAdmin = """
                    INSERT OR IGNORE INTO usuarios
                    (nombre, usuario, password, rol, estado)
                    VALUES
                    ('Administrador', 'admin', '12345', 'ADMIN', 1)
                    """;

            st.execute(sqlAdmin);

            System.out.println("Base de datos preparada correctamente.");

        } catch (SQLException e) {

            System.out.println(
                    "Error al crear las tablas: "
                    + e.getMessage()
            );
        }
    }

    public static void cerrar(Connection conexion) {

        if (conexion != null) {

            try {

                conexion.close();

            } catch (SQLException e) {

                System.out.println(
                        "Error al cerrar la conexión: "
                        + e.getMessage()
                );
            }
        }
    }
}