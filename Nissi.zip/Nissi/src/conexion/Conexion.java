
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class Conexion {

    private static final String URL = "jdbc:sqlite:nissi_accesorios.db";

    public static Connection conectar() throws SQLException {

        Connection conexion = DriverManager.getConnection(URL);

        try (Statement st = conexion.createStatement()) {
            st.execute("PRAGMA foreign_keys = ON");
        }

        crearTablas(conexion);

        return conexion;
    }

    private static void crearTablas(Connection conexion) {

        try (Statement st = conexion.createStatement()) {

            // USUARIOS
            st.execute("""
                    CREATE TABLE IF NOT EXISTS usuarios (
                        id_usuario INTEGER PRIMARY KEY AUTOINCREMENT,
                        nombre TEXT NOT NULL,
                        usuario TEXT NOT NULL UNIQUE,
                        password TEXT NOT NULL,
                        rol TEXT NOT NULL DEFAULT 'ADMIN',
                        estado INTEGER NOT NULL DEFAULT 1
                    )
                    """);

            // PRODUCTOS
            st.execute("""
                    CREATE TABLE IF NOT EXISTS productos (
                        id_producto INTEGER PRIMARY KEY AUTOINCREMENT,
                        codigo TEXT NOT NULL UNIQUE,
                        nombre TEXT NOT NULL,
                        categoria TEXT NOT NULL,
                        precio REAL NOT NULL CHECK(precio >= 0),
                        stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0),
                        descripcion TEXT,
                        estado INTEGER NOT NULL DEFAULT 1
                    )
                    """);

            // CLIENTES
            st.execute("""
                    CREATE TABLE IF NOT EXISTS clientes (
                        id_cliente INTEGER PRIMARY KEY AUTOINCREMENT,
                        documento TEXT NOT NULL UNIQUE,
                        nombre TEXT NOT NULL,
                        telefono TEXT,
                        correo TEXT,
                        direccion TEXT,
                        estado INTEGER NOT NULL DEFAULT 1
                    )
                    """);

            // VENTAS
            st.execute("""
                    CREATE TABLE IF NOT EXISTS ventas (
                        id_venta INTEGER PRIMARY KEY AUTOINCREMENT,
                        id_producto INTEGER NOT NULL,
                        codigo TEXT NOT NULL,
                        nombre TEXT NOT NULL,
                        cantidad INTEGER NOT NULL CHECK(cantidad > 0),
                        precio_unitario REAL NOT NULL,
                        total REAL NOT NULL,
                        usuario TEXT,
                        fecha TEXT NOT NULL DEFAULT
                            (datetime('now','localtime')),
                        id_cliente INTEGER,
                        cliente_nombre TEXT NOT NULL DEFAULT 'Consumidor final',
                        FOREIGN KEY (id_cliente)
                            REFERENCES clientes(id_cliente)
                            ON DELETE SET NULL
                    )
                    """);

            // FACTURAS
            st.execute("""
                    CREATE TABLE IF NOT EXISTS facturas (
                        id_factura INTEGER PRIMARY KEY AUTOINCREMENT,
                        fecha TEXT NOT NULL DEFAULT
                            (datetime('now','localtime')),
                        usuario TEXT NOT NULL,
                        total REAL NOT NULL DEFAULT 0 CHECK(total >= 0),
                        id_cliente INTEGER,
                        cliente_nombre TEXT NOT NULL DEFAULT 'Consumidor final',
                        FOREIGN KEY (id_cliente)
                            REFERENCES clientes(id_cliente)
                            ON DELETE SET NULL
                    )
                    """);

            // DETALLE DE FACTURA
            st.execute("""
                    CREATE TABLE IF NOT EXISTS detalle_factura (
                        id_detalle INTEGER PRIMARY KEY AUTOINCREMENT,
                        id_factura INTEGER NOT NULL,
                        id_producto INTEGER,
                        codigo TEXT NOT NULL,
                        nombre TEXT NOT NULL,
                        cantidad INTEGER NOT NULL CHECK(cantidad > 0),
                        precio_unitario REAL NOT NULL CHECK(precio_unitario >= 0),
                        subtotal REAL NOT NULL CHECK(subtotal >= 0),
                        FOREIGN KEY (id_factura)
                            REFERENCES facturas(id_factura)
                            ON DELETE CASCADE,
                        FOREIGN KEY (id_producto)
                            REFERENCES productos(id_producto)
                            ON DELETE SET NULL
                    )
                    """);

            // ACTUALIZAR BASES DE DATOS EXISTENTES
            agregarColumna(conexion, "ventas",
                    "id_cliente",
                    "INTEGER REFERENCES clientes(id_cliente) ON DELETE SET NULL");

            agregarColumna(conexion, "ventas",
                    "cliente_nombre",
                    "TEXT NOT NULL DEFAULT 'Consumidor final'");

            agregarColumna(conexion, "facturas",
                    "id_cliente",
                    "INTEGER REFERENCES clientes(id_cliente) ON DELETE SET NULL");

            agregarColumna(conexion, "facturas",
                    "cliente_nombre",
                    "TEXT NOT NULL DEFAULT 'Consumidor final'");

            // ÍNDICES
            st.execute("""
                    CREATE INDEX IF NOT EXISTS idx_facturas_fecha
                    ON facturas(fecha)
                    """);

            st.execute("""
                    CREATE INDEX IF NOT EXISTS idx_detalle_factura
                    ON detalle_factura(id_factura)
                    """);

            st.execute("""
                    CREATE INDEX IF NOT EXISTS idx_ventas_cliente
                    ON ventas(id_cliente)
                    """);

            st.execute("""
                    CREATE INDEX IF NOT EXISTS idx_facturas_cliente
                    ON facturas(id_cliente)
                    """);

            // ADMINISTRADOR INICIAL
            st.execute("""
                    INSERT OR IGNORE INTO usuarios
                    (nombre, usuario, password, rol, estado)
                    VALUES
                    ('Administrador', 'admin', '12345', 'ADMIN', 1)
                    """);

            System.out.println("Base de datos preparada correctamente.");

        } catch (SQLException e) {
            System.out.println(
                    "Error al crear las tablas: " + e.getMessage()
            );
        }
    }

    private static void agregarColumna(
            Connection conexion,
            String tabla,
            String columna,
            String definicion) throws SQLException {

        boolean existe = false;

        try (Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(
                     "PRAGMA table_info(" + tabla + ")")) {

            while (rs.next()) {
                if (columna.equalsIgnoreCase(rs.getString("name"))) {
                    existe = true;
                    break;
                }
            }
        }

        if (!existe) {
            try (Statement st = conexion.createStatement()) {
                st.execute(
                        "ALTER TABLE " + tabla
                        + " ADD COLUMN " + columna + " " + definicion
                );
            }
        }
    }

    public static void cerrar(Connection conexion) {

        if (conexion != null) {
            try {
                conexion.close();
            } catch (SQLException e) {
                System.out.println(
                        "Error al cerrar la conexión: " + e.getMessage()
                );
            }
        }
    }
}
