
package dao;

import conexion.Conexion;
import modelo.Usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    // =========================================
    // INICIAR SESION
    // =========================================
    public Usuario iniciarSesion(String usuario, String password) {

        String sql = """
                SELECT id_usuario, nombre, usuario, password, rol, estado
                FROM usuarios
                WHERE usuario = ?
                AND password = ?
                AND estado = 1
                """;

        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, usuario);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Usuario u = new Usuario();

                    u.setIdUsuario(rs.getInt("id_usuario"));
                    u.setNombre(rs.getString("nombre"));
                    u.setUsuario(rs.getString("usuario"));
                    u.setPassword(rs.getString("password"));
                    u.setRol(rs.getString("rol"));
                    u.setEstado(rs.getInt("estado"));

                    return u;
                }
            }

        } catch (Exception e) {
            System.out.println("Error al iniciar sesión: " + e.getMessage());
        }

        return null;
    }

    // =========================================
    // LISTAR TODOS LOS USUARIOS
    // =========================================
    public List<Usuario> listarUsuarios() {

        List<Usuario> lista = new ArrayList<>();

        String sql = """
                SELECT id_usuario, nombre, usuario, password, rol, estado
                FROM usuarios
                ORDER BY id_usuario DESC
                """;

        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Usuario u = new Usuario();

                u.setIdUsuario(rs.getInt("id_usuario"));
                u.setNombre(rs.getString("nombre"));
                u.setUsuario(rs.getString("usuario"));
                u.setPassword(rs.getString("password"));
                u.setRol(rs.getString("rol"));
                u.setEstado(rs.getInt("estado"));

                lista.add(u);
            }

        } catch (Exception e) {
            System.out.println("Error al listar usuarios: " + e.getMessage());
        }

        return lista;
    }

    // =========================================
    // REGISTRAR USUARIO
    // =========================================
    public boolean registrarUsuario(Usuario usuario) {

        String sql = """
                INSERT INTO usuarios (nombre, usuario, password, rol, estado)
                VALUES (?, ?, ?, ?, ?)
                """;

        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getUsuario());
            ps.setString(3, usuario.getPassword());
            ps.setString(4, usuario.getRol());
            ps.setInt(5, usuario.getEstado());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println("Error al registrar usuario: " + e.getMessage());
            return false;
        }
    }

    // =========================================
    // ACTUALIZAR USUARIO
    // =========================================
    public boolean actualizarUsuario(Usuario usuario) {

        String sql = """
                UPDATE usuarios
                SET nombre = ?,
                    usuario = ?,
                    password = ?,
                    rol = ?,
                    estado = ?
                WHERE id_usuario = ?
                """;

        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getUsuario());
            ps.setString(3, usuario.getPassword());
            ps.setString(4, usuario.getRol());
            ps.setInt(5, usuario.getEstado());
            ps.setInt(6, usuario.getIdUsuario());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println("Error al actualizar usuario: " + e.getMessage());
            return false;
        }
    }

    // =========================================
    // ELIMINAR USUARIO
    // =========================================
    public boolean eliminarUsuario(int idUsuario) {

        String sql = """
                DELETE FROM usuarios
                WHERE id_usuario = ?
                """;

        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println("Error al eliminar usuario: " + e.getMessage());
            return false;
        }
    }

    // =========================================
    // CONTAR ADMINISTRADORES ACTIVOS
    // =========================================
    public int contarAdministradoresActivos() {

        String sql = """
                SELECT COUNT(*)
                FROM usuarios
                WHERE rol = 'ADMIN'
                AND estado = 1
                """;

        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (Exception e) {
            System.out.println("Error al contar administradores: " + e.getMessage());
        }

        return 0;
    }

    // =========================================
    // VERIFICAR SI EXISTE UN NOMBRE DE USUARIO
    // =========================================
    public boolean existeUsuario(String usuario, int idExcluir) {

        String sql = """
                SELECT COUNT(*)
                FROM usuarios
                WHERE usuario = ?
                AND id_usuario <> ?
                """;

        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, usuario);
            ps.setInt(2, idExcluir);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }

        } catch (Exception e) {
            System.out.println("Error al verificar usuario: " + e.getMessage());
            return true;
        }
    }
}
