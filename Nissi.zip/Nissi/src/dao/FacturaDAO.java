
package dao;

import conexion.Conexion;
import modelo.Cliente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

public class FacturaDAO {

    // Compatibilidad con llamadas anteriores.
    public int registrarFactura(List<int[]> productos, String usuario)
            throws SQLException {

        return registrarFactura(productos, usuario, null);
    }

    // Registrar factura con cliente.
    public int registrarFactura(
            List<int[]> productos,
            String usuario,
            Cliente cliente) throws SQLException {

        if (productos == null || productos.isEmpty()) {
            throw new IllegalArgumentException(
                    "La factura debe contener al menos un producto."
            );
        }

        if (usuario == null || usuario.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "No se identificó el vendedor."
            );
        }

        if (cliente == null || cliente.getIdCliente() <= 0
                || cliente.getEstado() != 1) {
            throw new IllegalArgumentException(
                    "Selecciona un cliente activo."
            );
        }

        String sqlFactura = """
                INSERT INTO facturas
                (usuario, total, id_cliente, cliente_nombre)
                VALUES (?, 0, ?, ?)
                """;

        String sqlProducto = """
                SELECT codigo, nombre, precio
                FROM productos
                WHERE id_producto = ? AND estado = 1
                """;

        String sqlDescontar = """
                UPDATE productos
                SET stock = stock - ?
                WHERE id_producto = ?
                  AND stock >= ?
                  AND estado = 1
                """;

        String sqlDetalle = """
                INSERT INTO detalle_factura
                (id_factura, id_producto, codigo, nombre,
                 cantidad, precio_unitario, subtotal)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """;

        String sqlVenta = """
                INSERT INTO ventas
                (id_producto, codigo, nombre, cantidad,
                 precio_unitario, total, usuario,
                 id_cliente, cliente_nombre)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """;

        String sqlActualizarTotal = """
                UPDATE facturas
                SET total = ?
                WHERE id_factura = ?
                """;

        try (Connection con = Conexion.conectar()) {

            con.setAutoCommit(false);

            try {

                int idFactura;

                // 1. Crear factura con cliente.
                try (PreparedStatement ps = con.prepareStatement(
                        sqlFactura,
                        PreparedStatement.RETURN_GENERATED_KEYS)) {

                    ps.setString(1, usuario);
                    ps.setInt(2, cliente.getIdCliente());
                    ps.setString(3, cliente.getNombre());

                    ps.executeUpdate();

                    try (ResultSet rs = ps.getGeneratedKeys()) {
                        if (!rs.next()) {
                            throw new SQLException(
                                    "No se pudo generar el número de factura."
                            );
                        }
                        idFactura = rs.getInt(1);
                    }
                }

                double totalFactura = 0;

                // 2. Procesar cada producto.
                for (int[] item : productos) {

                    if (item == null || item.length < 2) {
                        throw new IllegalArgumentException(
                                "Producto con información inválida."
                        );
                    }

                    int idProducto = item[0];
                    int cantidad = item[1];

                    if (idProducto <= 0 || cantidad <= 0) {
                        throw new IllegalArgumentException(
                                "Producto o cantidad inválidos."
                        );
                    }

                    String codigo;
                    String nombre;
                    double precio;

                    // Consultar producto.
                    try (PreparedStatement ps =
                            con.prepareStatement(sqlProducto)) {

                        ps.setInt(1, idProducto);

                        try (ResultSet rs = ps.executeQuery()) {

                            if (!rs.next()) {
                                throw new SQLException(
                                        "El producto con ID " + idProducto
                                        + " no existe o está inactivo."
                                );
                            }

                            codigo = rs.getString("codigo");
                            nombre = rs.getString("nombre");
                            precio = rs.getDouble("precio");
                        }
                    }

                    double subtotal = precio * cantidad;
                    totalFactura += subtotal;

                    // Descontar inventario.
                    try (PreparedStatement ps =
                            con.prepareStatement(sqlDescontar)) {

                        ps.setInt(1, cantidad);
                        ps.setInt(2, idProducto);
                        ps.setInt(3, cantidad);

                        if (ps.executeUpdate() == 0) {
                            throw new SQLException(
                                    "Stock insuficiente para: " + nombre
                            );
                        }
                    }

                    // Guardar detalle de factura.
                    try (PreparedStatement ps =
                            con.prepareStatement(sqlDetalle)) {

                        ps.setInt(1, idFactura);
                        ps.setInt(2, idProducto);
                        ps.setString(3, codigo);
                        ps.setString(4, nombre);
                        ps.setInt(5, cantidad);
                        ps.setDouble(6, precio);
                        ps.setDouble(7, subtotal);

                        ps.executeUpdate();
                    }

                    // Guardar registro para el historial de ventas.
                    try (PreparedStatement ps =
                            con.prepareStatement(sqlVenta)) {

                        ps.setInt(1, idProducto);
                        ps.setString(2, codigo);
                        ps.setString(3, nombre);
                        ps.setInt(4, cantidad);
                        ps.setDouble(5, precio);
                        ps.setDouble(6, subtotal);
                        ps.setString(7, usuario);
                        ps.setInt(8, cliente.getIdCliente());
                        ps.setString(9, cliente.getNombre());

                        ps.executeUpdate();
                    }
                }

                // 3. Actualizar total de la factura.
                try (PreparedStatement ps =
                        con.prepareStatement(sqlActualizarTotal)) {

                    ps.setDouble(1, totalFactura);
                    ps.setInt(2, idFactura);
                    ps.executeUpdate();
                }

                // 4. Confirmar transacción.
                con.commit();

                return idFactura;

            } catch (SQLException | RuntimeException e) {

                con.rollback();
                throw e;

            } finally {
                con.setAutoCommit(true);
            }
        }
    }
}
