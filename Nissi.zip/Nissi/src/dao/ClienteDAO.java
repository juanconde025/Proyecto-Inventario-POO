/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author juanc
 */

import conexion.Conexion;
import modelo.Cliente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {

    // LISTAR CLIENTES
    public List<Cliente> listarClientes() {

        List<Cliente> lista = new ArrayList<>();

        String sql = """
                SELECT *
                FROM clientes
                ORDER BY id_cliente DESC
                """;

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Cliente cliente = new Cliente(
                        rs.getInt("id_cliente"),
                        rs.getString("documento"),
                        rs.getString("nombre"),
                        rs.getString("telefono"),
                        rs.getString("correo"),
                        rs.getString("direccion"),
                        rs.getInt("estado")
                );

                lista.add(cliente);
            }

        } catch (Exception e) {
            System.out.println("Error al listar clientes: " + e.getMessage());
        }

        return lista;
    }

    // BUSCAR CLIENTE POR ID
    public Cliente buscarPorId(int idCliente) {

        String sql = """
                SELECT *
                FROM clientes
                WHERE id_cliente = ?
                """;

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idCliente);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return new Cliente(
                            rs.getInt("id_cliente"),
                            rs.getString("documento"),
                            rs.getString("nombre"),
                            rs.getString("telefono"),
                            rs.getString("correo"),
                            rs.getString("direccion"),
                            rs.getInt("estado")
                    );
                }
            }

        } catch (Exception e) {
            System.out.println("Error al buscar cliente: " + e.getMessage());
        }

        return null;
    }

    // REGISTRAR CLIENTE
    public boolean registrarCliente(Cliente cliente) {

        String sql = """
                INSERT INTO clientes
                (documento, nombre, telefono, correo, direccion, estado)
                VALUES (?, ?, ?, ?, ?, ?)
                """;

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, cliente.getDocumento());
            ps.setString(2, cliente.getNombre());
            ps.setString(3, cliente.getTelefono());
            ps.setString(4, cliente.getCorreo());
            ps.setString(5, cliente.getDireccion());
            ps.setInt(6, cliente.getEstado());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println("Error al registrar cliente: " + e.getMessage());
            return false;
        }
    }

    // ACTUALIZAR CLIENTE
    public boolean actualizarCliente(Cliente cliente) {

        String sql = """
                UPDATE clientes
                SET documento = ?,
                    nombre = ?,
                    telefono = ?,
                    correo = ?,
                    direccion = ?,
                    estado = ?
                WHERE id_cliente = ?
                """;

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, cliente.getDocumento());
            ps.setString(2, cliente.getNombre());
            ps.setString(3, cliente.getTelefono());
            ps.setString(4, cliente.getCorreo());
            ps.setString(5, cliente.getDireccion());
            ps.setInt(6, cliente.getEstado());
            ps.setInt(7, cliente.getIdCliente());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println("Error al actualizar cliente: " + e.getMessage());
            return false;
        }
    }

    // DESACTIVAR CLIENTE (ELIMINACIÓN LÓGICA)
    public boolean eliminarCliente(int idCliente) {

        String sql = """
                UPDATE clientes
                SET estado = 0
                WHERE id_cliente = ?
                """;

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idCliente);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println("Error al desactivar cliente: " + e.getMessage());
            return false;
        }
    }

    // VERIFICAR DOCUMENTO DUPLICADO
    public boolean existeDocumento(String documento, int idExcluir) {

        String sql = """
                SELECT COUNT(*)
                FROM clientes
                WHERE documento = ?
                AND id_cliente <> ?
                """;

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, documento);
            ps.setInt(2, idExcluir);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }

        } catch (Exception e) {
            System.out.println("Error al verificar documento: " + e.getMessage());
            return true;
        }
    }
}

