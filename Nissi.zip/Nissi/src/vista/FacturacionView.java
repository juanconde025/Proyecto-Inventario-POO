
package vista;

import conexion.Conexion;
import controlador.ClienteController;
import dao.ClienteDAO;
import dao.FacturaDAO;
import modelo.Cliente;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FacturacionView extends JFrame {

    private JTextField txtCodigo;
    private JTextField txtCantidad;

    private JComboBox<Cliente> cmbClientes;

    private JTable tabla;
    private DefaultTableModel modelo;

    private JLabel lblTotal;

    private String usuario;
    private Runnable alRegistrarFactura;

    private final ClienteDAO clienteDAO = new ClienteDAO();

    public FacturacionView(String usuario) {
        this(usuario, null);
    }

    public FacturacionView(String usuario, Runnable alRegistrarFactura) {

        this.usuario = usuario;
        this.alRegistrarFactura = alRegistrarFactura;

        setTitle("Facturación - Nissi Accesorios");
        setSize(1050, 650);
        setMinimumSize(new Dimension(900, 580));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        crearInterfaz();
        cargarClientes();
    }

    private void crearInterfaz() {

        Color fondo = new Color(15, 23, 42);

        JPanel superior = new JPanel(new GridBagLayout());
        superior.setBackground(fondo);
        superior.setBorder(BorderFactory.createEmptyBorder(12, 15, 12, 15));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 6, 5, 6);
        gbc.gridy = 0;

        cmbClientes = new JComboBox<>();
        cmbClientes.setPreferredSize(new Dimension(240, 32));
        cmbClientes.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(
                    JList<?> list, Object value, int index,
                    boolean selected, boolean focus) {

                super.getListCellRendererComponent(
                        list, value, index, selected, focus
                );

                if (value instanceof Cliente) {
                    Cliente c = (Cliente) value;
                    setText(c.getDocumento() + " - " + c.getNombre());
                } else {
                    setText("Selecciona un cliente");
                }

                return this;
            }
        });

        JButton btnGestionarClientes = new JButton("Gestionar clientes");
        JButton btnActualizarClientes = new JButton("Actualizar lista");

        txtCodigo = new JTextField(12);
        txtCantidad = new JTextField("1", 4);

        JButton btnAgregar = new JButton("Agregar producto");

        gbc.gridx = 0;
        superior.add(new JLabel("Cliente:"), gbc);

        gbc.gridx = 1;
        superior.add(cmbClientes, gbc);

        gbc.gridx = 2;
        superior.add(btnGestionarClientes, gbc);

        gbc.gridx = 3;
        superior.add(btnActualizarClientes, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        superior.add(new JLabel("Código producto:"), gbc);

        gbc.gridx = 1;
        superior.add(txtCodigo, gbc);

        gbc.gridx = 2;
        superior.add(new JLabel("Cantidad:"), gbc);

        gbc.gridx = 3;
        superior.add(txtCantidad, gbc);

        gbc.gridx = 4;
        superior.add(btnAgregar, gbc);

        modelo = new DefaultTableModel(
                new Object[]{
                    "ID", "Código", "Producto",
                    "Cantidad", "Precio", "Subtotal"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabla = new JTable(modelo);
        tabla.setRowHeight(30);

        JScrollPane scroll = new JScrollPane(tabla);

        JPanel inferior = new JPanel(
                new FlowLayout(FlowLayout.RIGHT, 15, 15)
        );
        inferior.setBackground(fondo);

        lblTotal = new JLabel("TOTAL: $0.00");
        lblTotal.setForeground(new Color(74, 222, 128));
        lblTotal.setFont(new Font("Arial", Font.BOLD, 22));

        JButton btnEliminar = new JButton("Eliminar producto");
        JButton btnFinalizar = new JButton("Finalizar factura");

        inferior.add(btnEliminar);
        inferior.add(lblTotal);
        inferior.add(btnFinalizar);

        add(superior, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
        add(inferior, BorderLayout.SOUTH);

        btnAgregar.addActionListener(e -> agregarProducto());
        btnEliminar.addActionListener(e -> eliminarProducto());
        btnFinalizar.addActionListener(e -> finalizarFactura());

        btnActualizarClientes.addActionListener(e -> cargarClientes());

        btnGestionarClientes.addActionListener(e -> abrirGestionClientes());
    }

    // =========================================
    // CLIENTES
    // =========================================
    private void cargarClientes() {

        cmbClientes.removeAllItems();

        List<Cliente> clientes = clienteDAO.listarClientes();

        for (Cliente cliente : clientes) {
            if (cliente.getEstado() == 1) {
                cmbClientes.addItem(cliente);
            }
        }

        if (cmbClientes.getItemCount() > 0) {
            cmbClientes.setSelectedIndex(0);
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "No hay clientes activos. Registra un cliente antes de facturar."
            );
        }
    }

    private void abrirGestionClientes() {

        ClientesView ventana = new ClientesView();
        new ClienteController(ventana);

        ventana.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                cargarClientes();
            }
        });

        ventana.setVisible(true);
    }

    // =========================================
    // PRODUCTOS
    // =========================================
    private void agregarProducto() {

        String codigo = txtCodigo.getText().trim();

        if (codigo.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this, "Ingresa el código del producto."
            );
            return;
        }

        int cantidad;

        try {
            cantidad = Integer.parseInt(txtCantidad.getText().trim());

            if (cantidad <= 0) {
                throw new NumberFormatException();
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this, "Ingresa una cantidad válida."
            );
            return;
        }

        try (Connection con = Conexion.conectar()) {

            String sql = """
                    SELECT id_producto, codigo, nombre, precio, stock
                    FROM productos
                    WHERE codigo = ? AND estado = 1
                    """;

            try (PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, codigo);

                try (ResultSet rs = ps.executeQuery()) {

                    if (!rs.next()) {
                        JOptionPane.showMessageDialog(
                                this, "Producto no encontrado."
                        );
                        return;
                    }

                    int id = rs.getInt("id_producto");
                    String nombre = rs.getString("nombre");
                    double precio = rs.getDouble("precio");
                    int stock = rs.getInt("stock");

                    int filaExistente = buscarProducto(id);
                    int cantidadFinal = cantidad;

                    if (filaExistente >= 0) {
                        cantidadFinal += (int) modelo.getValueAt(
                                filaExistente, 3
                        );
                    }

                    if (cantidadFinal > stock) {
                        JOptionPane.showMessageDialog(
                                this,
                                "Stock insuficiente. Disponible: " + stock
                        );
                        return;
                    }

                    double subtotal = precio * cantidadFinal;

                    if (filaExistente >= 0) {

                        modelo.setValueAt(
                                cantidadFinal, filaExistente, 3
                        );

                        modelo.setValueAt(
                                subtotal, filaExistente, 5
                        );

                    } else {

                        modelo.addRow(new Object[]{
                            id,
                            rs.getString("codigo"),
                            nombre,
                            cantidad,
                            precio,
                            precio * cantidad
                        });
                    }

                    actualizarTotal();

                    txtCodigo.setText("");
                    txtCantidad.setText("1");
                }
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error al buscar producto: " + e.getMessage()
            );
        }
    }

    private int buscarProducto(int id) {

        for (int i = 0; i < modelo.getRowCount(); i++) {

            if ((int) modelo.getValueAt(i, 0) == id) {
                return i;
            }
        }

        return -1;
    }

    private void eliminarProducto() {

        int fila = tabla.getSelectedRow();

        if (fila < 0) {
            JOptionPane.showMessageDialog(
                    this, "Selecciona un producto."
            );
            return;
        }

        modelo.removeRow(fila);
        actualizarTotal();
    }

    private void actualizarTotal() {

        double total = 0;

        for (int i = 0; i < modelo.getRowCount(); i++) {
            total += ((Number) modelo.getValueAt(i, 5)).doubleValue();
        }

        lblTotal.setText(
                String.format("TOTAL: $%,.2f", total)
        );
    }

    // =========================================
    // FINALIZAR FACTURA
    // =========================================
    private void finalizarFactura() {

        if (cmbClientes.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(
                    this, "Selecciona un cliente para la factura."
            );
            return;
        }

        if (modelo.getRowCount() == 0) {
            JOptionPane.showMessageDialog(
                    this, "Agrega productos antes de finalizar."
            );
            return;
        }

        Cliente cliente = (Cliente) cmbClientes.getSelectedItem();

        int confirmar = JOptionPane.showConfirmDialog(
                this,
                "Cliente: " + cliente.getNombre()
                + "\nDocumento: " + cliente.getDocumento()
                + "\n" + lblTotal.getText()
                + "\n\n¿Deseas registrar esta factura?",
                "Confirmar factura",
                JOptionPane.YES_NO_OPTION
        );

        if (confirmar != JOptionPane.YES_OPTION) {
            return;
        }

        List<int[]> productos = new ArrayList<>();

        for (int i = 0; i < modelo.getRowCount(); i++) {

            int id = (int) modelo.getValueAt(i, 0);
            int cantidad = (int) modelo.getValueAt(i, 3);

            productos.add(new int[]{id, cantidad});
        }

        try {

            FacturaDAO dao = new FacturaDAO();

            int idFactura = dao.registrarFactura(
                    productos, usuario, cliente
            );

            if (alRegistrarFactura != null) {
                alRegistrarFactura.run();
            }

            JOptionPane.showMessageDialog(
                    this,
                    "Factura registrada correctamente."
                    + "\nNúmero: " + idFactura
                    + "\nCliente: " + cliente.getNombre()
            );

            modelo.setRowCount(0);
            actualizarTotal();

        } catch (SQLException | IllegalArgumentException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "No se pudo registrar la factura:\n" + e.getMessage(),
                    "Error de facturación",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}
