/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

/**
 *
 * @author juanc
 */

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;

public class UsuariosView extends JFrame {

    private JTextField txtId;
    private JTextField txtNombre;
    private JTextField txtUsuario;
    private JPasswordField txtPassword;

    private JComboBox<String> cmbRol;
    private JComboBox<String> cmbEstado;

    private JTable tablaUsuarios;
    private DefaultTableModel modeloTabla;

    private JButton btnNuevo;
    private JButton btnGuardar;
    private JButton btnActualizar;
    private JButton btnEliminar;
    private JButton btnLimpiar;
    private JButton btnCerrar;

    private JLabel lblInfo;

    private static final Color FONDO = new Color(15, 23, 42);
    private static final Color PANEL = new Color(30, 41, 59);
    private static final Color VERDE = new Color(22, 101, 52);
    private static final Color TEXTO = new Color(226, 232, 240);
    private static final Color SECUNDARIO = new Color(148, 163, 184);

    public UsuariosView() {

        setTitle("Nissi Accesorios - Gestión de usuarios");
        setSize(1050, 680);
        setMinimumSize(new Dimension(950, 600));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        inicializarComponentes();
    }

    private void inicializarComponentes() {

        JPanel fondo = new JPanel(new BorderLayout(0, 20));
        fondo.setBackground(FONDO);
        fondo.setBorder(new EmptyBorder(25, 28, 25, 28));

        fondo.add(crearEncabezado(), BorderLayout.NORTH);
        fondo.add(crearContenido(), BorderLayout.CENTER);

        setContentPane(fondo);
    }

    // =========================================
    // ENCABEZADO
    // =========================================
    private JPanel crearEncabezado() {

        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        JPanel textos = new JPanel(new GridLayout(2, 1, 0, 5));
        textos.setOpaque(false);

        JLabel titulo = new JLabel("Gestión de usuarios");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 27));
        titulo.setForeground(Color.WHITE);

        JLabel subtitulo = new JLabel(
                "Administra las cuentas y los permisos de Nissi Accesorios"
        );
        subtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitulo.setForeground(SECUNDARIO);

        textos.add(titulo);
        textos.add(subtitulo);

        btnCerrar = crearBoton(
                "Cerrar",
                new Color(100, 116, 139),
                new Color(71, 85, 105)
        );

        panel.add(textos, BorderLayout.WEST);
        panel.add(btnCerrar, BorderLayout.EAST);

        btnCerrar.addActionListener(e -> dispose());

        return panel;
    }

    // =========================================
    // CONTENIDO PRINCIPAL
    // =========================================
    private JPanel crearContenido() {

        JPanel contenido = new JPanel(new BorderLayout(18, 0));
        contenido.setOpaque(false);

        contenido.add(crearFormulario(), BorderLayout.WEST);
        contenido.add(crearTabla(), BorderLayout.CENTER);

        return contenido;
    }

    // =========================================
    // FORMULARIO
    // =========================================
    private JPanel crearFormulario() {

        JPanel tarjeta = crearTarjeta();
        tarjeta.setPreferredSize(new Dimension(330, 0));
        tarjeta.setLayout(new BorderLayout(0, 15));

        JLabel titulo = new JLabel("Datos del usuario");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 19));
        titulo.setForeground(Color.WHITE);

        tarjeta.add(titulo, BorderLayout.NORTH);

        JPanel formulario = new JPanel(new GridBagLayout());
        formulario.setOpaque(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        gbc.insets = new Insets(5, 0, 5, 0);

        txtId = crearCampo();
        txtId.setEditable(false);

        txtNombre = crearCampo();
        txtUsuario = crearCampo();
        txtPassword = new JPasswordField();
        estilizarCampo(txtPassword);

        cmbRol = new JComboBox<>(new String[]{
            "VENDEDOR", "ADMIN"
        });
        estilizarCombo(cmbRol);

        cmbEstado = new JComboBox<>(new String[]{
            "ACTIVO", "INACTIVO"
        });
        estilizarCombo(cmbEstado);

        agregarCampo(formulario, gbc, 0, "ID", txtId);
        agregarCampo(formulario, gbc, 1, "Nombre completo", txtNombre);
        agregarCampo(formulario, gbc, 2, "Nombre de usuario", txtUsuario);
        agregarCampo(formulario, gbc, 3, "Contraseña", txtPassword);
        agregarCampo(formulario, gbc, 4, "Rol", cmbRol);
        agregarCampo(formulario, gbc, 5, "Estado", cmbEstado);

        tarjeta.add(formulario, BorderLayout.CENTER);

        JPanel botones = new JPanel(new GridLayout(3, 2, 8, 8));
        botones.setOpaque(false);

        btnNuevo = crearBoton(
                "Nuevo",
                new Color(71, 85, 105),
                new Color(51, 65, 85)
        );

        btnGuardar = crearBoton(
                "Guardar",
                new Color(34, 160, 90),
                new Color(22, 101, 52)
        );

        btnActualizar = crearBoton(
                "Actualizar",
                new Color(180, 130, 35),
                new Color(130, 90, 20)
        );

        btnEliminar = crearBoton(
                "Eliminar",
                new Color(190, 55, 70),
                new Color(130, 30, 50)
        );

        btnLimpiar = crearBoton(
                "Limpiar",
                new Color(100, 116, 139),
                new Color(71, 85, 105)
        );

        botones.add(btnNuevo);
        botones.add(btnGuardar);
        botones.add(btnActualizar);
        botones.add(btnEliminar);
        botones.add(btnLimpiar);

        tarjeta.add(botones, BorderLayout.SOUTH);

        return tarjeta;
    }

    private void agregarCampo(
            JPanel panel,
            GridBagConstraints gbc,
            int fila,
            String etiqueta,
            JComponent campo) {

        gbc.gridy = fila * 2;
        JLabel lbl = new JLabel(etiqueta);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lbl.setForeground(TEXTO);
        panel.add(lbl, gbc);

        gbc.gridy = fila * 2 + 1;
        panel.add(campo, gbc);
    }

    // =========================================
    // TABLA DE USUARIOS
    // =========================================
    private JPanel crearTabla() {

        JPanel tarjeta = crearTarjeta();
        tarjeta.setLayout(new BorderLayout(0, 15));

        JLabel titulo = new JLabel("Usuarios registrados");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 19));
        titulo.setForeground(Color.WHITE);

        tarjeta.add(titulo, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(
                new String[]{
                    "ID", "Nombre", "Usuario", "Rol", "Estado"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };

        tablaUsuarios = new JTable(modeloTabla);

        tablaUsuarios.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tablaUsuarios.setForeground(TEXTO);
        tablaUsuarios.setBackground(PANEL);
        tablaUsuarios.setRowHeight(36);
        tablaUsuarios.setSelectionBackground(new Color(22, 101, 52));
        tablaUsuarios.setSelectionForeground(Color.WHITE);
        tablaUsuarios.setGridColor(new Color(51, 65, 85));
        tablaUsuarios.setShowVerticalLines(false);
        tablaUsuarios.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        JTableHeader encabezado = tablaUsuarios.getTableHeader();
        encabezado.setFont(new Font("Segoe UI", Font.BOLD, 13));
        encabezado.setBackground(VERDE);
        encabezado.setForeground(Color.WHITE);
        encabezado.setPreferredSize(new Dimension(0, 40));
        encabezado.setReorderingAllowed(false);

        tablaUsuarios.getColumnModel().getColumn(0).setPreferredWidth(40);
        tablaUsuarios.getColumnModel().getColumn(1).setPreferredWidth(160);
        tablaUsuarios.getColumnModel().getColumn(2).setPreferredWidth(110);
        tablaUsuarios.getColumnModel().getColumn(3).setPreferredWidth(85);
        tablaUsuarios.getColumnModel().getColumn(4).setPreferredWidth(85);

        JScrollPane scroll = new JScrollPane(tablaUsuarios);
        scroll.setBorder(BorderFactory.createLineBorder(
                new Color(51, 65, 85)
        ));
        scroll.getViewport().setBackground(PANEL);

        tarjeta.add(scroll, BorderLayout.CENTER);

        lblInfo = new JLabel("Selecciona un usuario para consultar sus datos.");
        lblInfo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblInfo.setForeground(SECUNDARIO);

        tarjeta.add(lblInfo, BorderLayout.SOUTH);

        return tarjeta;
    }

    // =========================================
    // ESTILOS
    // =========================================
    private JPanel crearTarjeta() {

        JPanel tarjeta = new JPanel();
        tarjeta.setBackground(PANEL);
        tarjeta.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                        new Color(71, 85, 105), 1
                ),
                new EmptyBorder(20, 20, 20, 20)
        ));

        return tarjeta;
    }

    private JTextField crearCampo() {

        JTextField campo = new JTextField();
        estilizarCampo(campo);
        return campo;
    }

    private void estilizarCampo(JTextField campo) {

        campo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        campo.setForeground(TEXTO);
        campo.setCaretColor(new Color(74, 222, 128));
        campo.setBackground(new Color(42, 52, 68));
        campo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                        new Color(71, 85, 105)
                ),
                new EmptyBorder(8, 10, 8, 10)
        ));
        campo.setPreferredSize(new Dimension(200, 38));
    }

    private void estilizarCombo(JComboBox<String> combo) {

        combo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        combo.setForeground(TEXTO);
        combo.setBackground(new Color(42, 52, 68));
        combo.setPreferredSize(new Dimension(200, 38));
    }

    private JButton crearBoton(
            String texto,
            Color color1,
            Color color2) {

        JButton boton = new JButton(texto);

        boton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        boton.setForeground(Color.WHITE);
        boton.setBackground(color1);
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.setPreferredSize(new Dimension(100, 40));

        boton.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                boton.setBackground(color1.brighter());
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                boton.setBackground(color1);
            }
        });

        return boton;
    }

    // =========================================
    // GETTERS PARA EL CONTROLADOR
    // =========================================
    public JTextField getTxtId() {
        return txtId;
    }

    public JTextField getTxtNombre() {
        return txtNombre;
    }

    public JTextField getTxtUsuario() {
        return txtUsuario;
    }

    public JPasswordField getTxtPassword() {
        return txtPassword;
    }

    public JComboBox<String> getCmbRol() {
        return cmbRol;
    }

    public JComboBox<String> getCmbEstado() {
        return cmbEstado;
    }

    public JTable getTablaUsuarios() {
        return tablaUsuarios;
    }

    public DefaultTableModel getModeloTabla() {
        return modeloTabla;
    }

    public JButton getBtnNuevo() {
        return btnNuevo;
    }

    public JButton getBtnGuardar() {
        return btnGuardar;
    }

    public JButton getBtnActualizar() {
        return btnActualizar;
    }

    public JButton getBtnEliminar() {
        return btnEliminar;
    }

    public JButton getBtnLimpiar() {
        return btnLimpiar;
    }

    public JLabel getLblInfo() {
        return lblInfo;
    }

    public void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Nissi Accesorios",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    public int confirmar(String mensaje) {
        return JOptionPane.showConfirmDialog(
                this,
                mensaje,
                "Confirmar acción",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
    }

    public void limpiarFormulario() {
        txtId.setText("");
        txtNombre.setText("");
        txtUsuario.setText("");
        txtPassword.setText("");
        cmbRol.setSelectedItem("VENDEDOR");
        cmbEstado.setSelectedItem("ACTIVO");
        tablaUsuarios.clearSelection();
    }
}
