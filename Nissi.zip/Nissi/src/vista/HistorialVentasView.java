
package vista;

import dao.VentaDAO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.util.List;
import java.util.Locale;

public class HistorialVentasView extends JDialog {

    private final VentaDAO ventaDAO = new VentaDAO();
    private final Locale co = Locale.forLanguageTag("es-CO");

    // Paleta de colores del sistema
    private final Color FONDO = new Color(22, 26, 24);
    private final Color PANEL = new Color(31, 37, 34);
    private final Color PANEL_CLARO = new Color(39, 46, 42);
    private final Color VERDE = new Color(78, 142, 77);
    private final Color VERDE_OSCURO = new Color(48, 95, 51);
    private final Color TEXTO = new Color(240, 245, 240);
    private final Color TEXTO_SECUNDARIO = new Color(170, 182, 173);

    private DefaultTableModel modelo;
    private JComboBox<String> cmbPeriodo;
    private JLabel lblHoy, lblSemana, lblMes, lblResumen;

    public HistorialVentasView(JFrame padre) {
        super(padre, "Historial de ventas", true);

        setSize(1000, 640);
        setMinimumSize(new Dimension(850, 550));
        setLocationRelativeTo(padre);

        inicializar();
        cargar();
    }

    private void inicializar() {

        JPanel fondo = new JPanel(new BorderLayout(0, 16));
        fondo.setBackground(FONDO);
        fondo.setBorder(new EmptyBorder(20, 24, 20, 24));

        // ---------- Superior ----------

        JLabel titulo = new JLabel("HISTORIAL DE VENTAS");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 25));
        titulo.setForeground(TEXTO);

        JLabel subtitulo = new JLabel("Consulta y seguimiento de las ventas realizadas");
        subtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitulo.setForeground(TEXTO_SECUNDARIO);

        JPanel encabezadoTexto = new JPanel();
        encabezadoTexto.setLayout(new BoxLayout(encabezadoTexto, BoxLayout.Y_AXIS));
        encabezadoTexto.setOpaque(false);
        encabezadoTexto.add(titulo);
        encabezadoTexto.add(Box.createVerticalStrut(5));
        encabezadoTexto.add(subtitulo);

        cmbPeriodo = new JComboBox<>(new String[]{
            "Hoy", "Últimos 7 días", "Este mes", "Todo"
        });

        cmbPeriodo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cmbPeriodo.setBackground(PANEL_CLARO);
        cmbPeriodo.setForeground(TEXTO);
        cmbPeriodo.setFocusable(false);
        cmbPeriodo.setPreferredSize(new Dimension(155, 36));

        cmbPeriodo.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(
                    JList<?> list, Object value, int index,
                    boolean selected, boolean focus) {

                super.getListCellRendererComponent(
                        list, value, index, selected, focus);

                setBackground(selected ? VERDE_OSCURO : PANEL_CLARO);
                setForeground(TEXTO);
                setBorder(new EmptyBorder(6, 9, 6, 9));

                return this;
            }
        });

        cmbPeriodo.addActionListener(e -> cargar());

        JLabel lblPeriodo = new JLabel("Mostrar:");
        lblPeriodo.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblPeriodo.setForeground(TEXTO_SECUNDARIO);

        JPanel filtro = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        filtro.setOpaque(false);
        filtro.add(lblPeriodo);
        filtro.add(cmbPeriodo);

        JPanel fila1 = new JPanel(new BorderLayout());
        fila1.setOpaque(false);
        fila1.add(encabezadoTexto, BorderLayout.WEST);
        fila1.add(filtro, BorderLayout.EAST);

        // ---------- Tarjetas de totales ----------

        lblHoy = new JLabel("$ 0");
        lblSemana = new JLabel("$ 0");
        lblMes = new JLabel("$ 0");

        JPanel totales = new JPanel(new GridLayout(1, 3, 14, 0));
        totales.setOpaque(false);

        totales.add(tarjetaTotal("VENDIDO HOY", lblHoy));
        totales.add(tarjetaTotal("ÚLTIMOS 7 DÍAS", lblSemana));
        totales.add(tarjetaTotal("ESTE MES", lblMes));

        JPanel superior = new JPanel(new BorderLayout(0, 16));
        superior.setOpaque(false);
        superior.add(fila1, BorderLayout.NORTH);
        superior.add(totales, BorderLayout.CENTER);

        // ---------- Tabla ----------

        modelo = new DefaultTableModel(new String[]{
            "N°", "Fecha", "Código", "Producto", "Cant.",
            "Precio unit.", "Total", "Vendedor", "Cliente"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        JTable tabla = new JTable(modelo) {

            @Override
            public Component prepareRenderer(
                    TableCellRenderer renderer, int row, int col) {

                Component c = super.prepareRenderer(renderer, row, col);

                if (!isRowSelected(row)) {
                    c.setBackground(row % 2 == 0 ? PANEL : PANEL_CLARO);
                    c.setForeground(TEXTO);
                } else {
                    c.setBackground(VERDE_OSCURO);
                    c.setForeground(Color.WHITE);
                }

                return c;
            }
        };

        tabla.setRowHeight(34);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabla.setForeground(TEXTO);
        tabla.setBackground(PANEL);
        tabla.setSelectionBackground(VERDE_OSCURO);
        tabla.setSelectionForeground(Color.WHITE);
        tabla.setGridColor(new Color(55, 65, 58));
        tabla.setShowVerticalLines(false);
        tabla.setShowHorizontalLines(true);
        tabla.setIntercellSpacing(new Dimension(0, 1));
        tabla.setFillsViewportHeight(true);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Encabezado de la tabla

        JTableHeader enc = tabla.getTableHeader();
        enc.setFont(new Font("Segoe UI", Font.BOLD, 13));
        enc.setBackground(VERDE_OSCURO);
        enc.setForeground(Color.WHITE);
        enc.setPreferredSize(new Dimension(0, 40));
        enc.setReorderingAllowed(false);
        enc.setBorder(BorderFactory.createEmptyBorder());

        // Formato de valores monetarios

        DefaultTableCellRenderer dinero = new DefaultTableCellRenderer() {

            @Override
            protected void setValue(Object v) {

                if (v instanceof Number) {
                    setText(String.format(
                            co, "$ %,.0f", ((Number) v).doubleValue()));
                } else {
                    setText(v == null ? "" : v.toString());
                }

                setHorizontalAlignment(RIGHT);
                setForeground(TEXTO);
            }
        };

        tabla.getColumnModel().getColumn(5).setCellRenderer(dinero);
        tabla.getColumnModel().getColumn(6).setCellRenderer(dinero);

        int[] anchos = {50, 150, 80, 210, 55, 105, 105, 100, 180};

        for (int i = 0; i < anchos.length; i++) {
            tabla.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
        }

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createLineBorder(
                new Color(55, 65, 58), 1));
        scroll.getViewport().setBackground(PANEL);
        scroll.getVerticalScrollBar().setBackground(PANEL);
        scroll.getHorizontalScrollBar().setBackground(PANEL);

        // ---------- Inferior ----------

        lblResumen = new JLabel(" ");
        lblResumen.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblResumen.setForeground(new Color(130, 190, 125));

        MenuPrincipalView.Boton btnCerrar =
                new MenuPrincipalView.Boton(
                        "Cerrar",
                        VERDE,
                        VERDE_OSCURO,
                        110,
                        40
                );

        btnCerrar.setForeground(Color.WHITE);
        btnCerrar.addActionListener(e -> dispose());

        JPanel inferior = new JPanel(new BorderLayout());
        inferior.setOpaque(false);
        inferior.setBorder(new EmptyBorder(5, 0, 0, 0));
        inferior.add(lblResumen, BorderLayout.WEST);
        inferior.add(btnCerrar, BorderLayout.EAST);

        // ---------- Agregar componentes ----------

        fondo.add(superior, BorderLayout.NORTH);
        fondo.add(scroll, BorderLayout.CENTER);
        fondo.add(inferior, BorderLayout.SOUTH);

        setContentPane(fondo);
    }

    // ---------- Tarjetas de totales ----------

    private JPanel tarjetaTotal(String texto, JLabel valor) {

        JPanel p = new JPanel(new GridLayout(2, 1, 0, 8)) {

            @Override
            protected void paintComponent(Graphics g) {

                super.paintComponent(g);

                Graphics2D g2 = (Graphics2D) g.create();

                g2.setRenderingHint(
                        RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON
                );

                g2.setColor(PANEL);
                g2.fillRoundRect(
                        0, 0, getWidth() - 1, getHeight() - 1, 18, 18
                );

                g2.setColor(new Color(65, 83, 69));
                g2.drawRoundRect(
                        0, 0, getWidth() - 2, getHeight() - 2, 18, 18
                );

                g2.dispose();
            }
        };

        p.setOpaque(false);
        p.setBorder(new EmptyBorder(13, 18, 13, 18));

        JLabel t = new JLabel(texto);
        t.setFont(new Font("Segoe UI", Font.BOLD, 12));
        t.setForeground(TEXTO_SECUNDARIO);

        valor.setFont(new Font("Segoe UI", Font.BOLD, 24));
        valor.setForeground(new Color(130, 190, 125));

        p.add(t);
        p.add(valor);

        return p;
    }

    // ---------- Cargar ventas ----------

    private void cargar() {

        try {

            List<Object[]> filas =
                    ventaDAO.listarVentas(cmbPeriodo.getSelectedIndex());

            modelo.setRowCount(0);

            int unidades = 0;
            double suma = 0;

            for (Object[] f : filas) {

                modelo.addRow(f);

                unidades += ((Number) f[4]).intValue();
                suma += ((Number) f[6]).doubleValue();
            }

            double[] t = ventaDAO.totales();

            lblHoy.setText(String.format(co, "$ %,.0f", t[0]));
            lblSemana.setText(String.format(co, "$ %,.0f", t[1]));
            lblMes.setText(String.format(co, "$ %,.0f", t[2]));

            lblResumen.setText(
                    "Ventas: " + filas.size()
                    + "   |   Unidades: " + unidades
                    + "   |   Total del período: "
                    + String.format(co, "$ %,.0f", suma)
            );

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error al cargar las ventas: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}
