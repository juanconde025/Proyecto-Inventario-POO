/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

/**
 *
 * @author juanc
 */

import controlador.LoginController;

import javax.swing.*;
import java.awt.*;

public class LoginView extends JFrame {

    private JTextField txtUsuario;
    private JPasswordField txtPassword;
    private JButton btnIngresar;

    public LoginView() {

        setTitle("Nissi Accesorios - Inicio de Sesión");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        inicializarComponentes();

        new LoginController(this);
    }

    private void inicializarComponentes() {

        JPanel panel = new JPanel();
        panel.setBorder(
                BorderFactory.createEmptyBorder(25, 30, 25, 30)
        );

        panel.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();

        JLabel lblTitulo =
                new JLabel("NISSI ACCESORIOS");

        lblTitulo.setFont(
                new Font("Arial", Font.BOLD, 24)
        );

        JLabel lblUsuario =
                new JLabel("Usuario:");

        JLabel lblPassword =
                new JLabel("Contraseña:");

        txtUsuario = new JTextField(18);

        txtPassword = new JPasswordField(18);

        btnIngresar =
                new JButton("Ingresar");

        gbc.insets =
                new Insets(8, 8, 8, 8);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;

        panel.add(lblTitulo, gbc);

        gbc.gridwidth = 1;

        gbc.gridx = 0;
        gbc.gridy = 1;

        panel.add(lblUsuario, gbc);

        gbc.gridx = 1;

        panel.add(txtUsuario, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;

        panel.add(lblPassword, gbc);

        gbc.gridx = 1;

        panel.add(txtPassword, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;

        panel.add(btnIngresar, gbc);

        add(panel);
    }

    public JTextField getTxtUsuario() {
        return txtUsuario;
    }

    public JPasswordField getTxtPassword() {
        return txtPassword;
    }

    public JButton getBtnIngresar() {
        return btnIngresar;
    }

    public void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Nissi Accesorios",
                JOptionPane.INFORMATION_MESSAGE
        );
    }
}
