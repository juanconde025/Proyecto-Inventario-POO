package vista;

import controlador.LoginController;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LoginView extends JFrame {

    private CampoTexto txtUsuario;
    private CampoClave txtPassword;
    private BotonRedondo btnIngresar;

    // Paleta verde y negro de Nissi Accesorios
    private static final Color FONDO = new Color(22, 26, 24);
    private static final Color PANEL = new Color(31, 37, 34);
    private static final Color VERDE = new Color(78, 142, 77);
    private static final Color VERDE_CLARO = new Color(130, 190, 125);
    private static final Color TEXTO = new Color(240, 245, 240);
    private static final Color TEXTO_SECUNDARIO = new Color(170, 182, 173);

    public LoginView() {

        setTitle("Nissi Accesorios - Inicio de Sesión");
        setSize(440, 640);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        inicializarComponentes();

        getRootPane().setDefaultButton(btnIngresar);

        new LoginController(this);
    }

    private void inicializarComponentes() {

        // Fondo principal oscuro
        JPanel fondo = new JPanel(new GridBagLayout());
        fondo.setBackground(FONDO);

        // Tarjeta central
        JPanel tarjeta = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(
                        RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON
                );

                // Sombra
                g2.setColor(new Color(0, 0, 0, 90));
                g2.fillRoundRect(
                        6, 8, getWidth() - 12, getHeight() - 12, 30, 30
                );

                // Fondo de la tarjeta
                g2.setColor(PANEL);
                g2.fillRoundRect(
                        0, 0, getWidth() - 8, getHeight() - 8, 30, 30
                );

                // Borde verde discreto
                g2.setColor(new Color(65, 95, 68));
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(
                        0, 0, getWidth() - 9, getHeight() - 9, 30, 30
                );

                g2.dispose();
            }
        };

        tarjeta.setOpaque(false);
        tarjeta.setBorder(new EmptyBorder(25, 35, 30, 43));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 0, 5, 0);

        // Logo
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.NONE;
        tarjeta.add(new LogoPanel(), gbc);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel lblTitulo = new JLabel(
                "NISSI ACCESORIOS", SwingConstants.CENTER
        );
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblTitulo.setForeground(TEXTO);

        gbc.gridy = 1;
        gbc.insets = new Insets(10, 0, 0, 0);
        tarjeta.add(lblTitulo, gbc);

        JLabel lblSub = new JLabel(
                "Accesorios & Tecnología", SwingConstants.CENTER
        );
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSub.setForeground(VERDE_CLARO);

        gbc.gridy = 2;
        gbc.insets = new Insets(0, 0, 25, 0);
        tarjeta.add(lblSub, gbc);

        // Usuario
        JLabel lblUsuario = new JLabel("Usuario");
        lblUsuario.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblUsuario.setForeground(TEXTO);

        gbc.gridy = 3;
        gbc.insets = new Insets(5, 8, 3, 0);
        tarjeta.add(lblUsuario, gbc);

        txtUsuario = new CampoTexto();

        gbc.gridy = 4;
        gbc.insets = new Insets(0, 0, 12, 0);
        tarjeta.add(txtUsuario, gbc);

        // Contraseña
        JLabel lblPassword = new JLabel("Contraseña");
        lblPassword.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblPassword.setForeground(TEXTO);

        gbc.gridy = 5;
        gbc.insets = new Insets(5, 8, 3, 0);
        tarjeta.add(lblPassword, gbc);

        txtPassword = new CampoClave();

        gbc.gridy = 6;
        gbc.insets = new Insets(0, 0, 25, 0);
        tarjeta.add(txtPassword, gbc);

        // Botón ingresar
        btnIngresar = new BotonRedondo("INGRESAR");

        gbc.gridy = 7;
        gbc.insets = new Insets(0, 0, 0, 0);
        tarjeta.add(btnIngresar, gbc);

        fondo.add(tarjeta);
        setContentPane(fondo);
    }

    public JTextField getTxtUsuario() {
        return txtUsuario;
    }

    public JPasswordField getTxtPassword() {
        return txtPassword;
    }

    public JButton getBtnIngresar() {
        return btnIngresar;
    }

    public void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Nissi Accesorios",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    // Pinta los campos con fondo oscuro y borde verde al tener el foco
    private static void pintarCampo(Graphics g, JComponent c) {

        Graphics2D g2 = (Graphics2D) g.create();

        g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
        );

        int w = c.getWidth();
        int h = c.getHeight();

        // Sombra
        g2.setColor(new Color(0, 0, 0, 75));
        g2.fillRoundRect(2, 4, w - 4, h - 4, h, h);

        // Cuerpo oscuro
        g2.setColor(new Color(42, 49, 44));
        g2.fillRoundRect(0, 0, w - 4, h - 5, h - 5, h - 5);

        // Borde según el foco
        g2.setColor(c.hasFocus() ? VERDE_CLARO : new Color(75, 88, 78));
        g2.setStroke(new BasicStroke(c.hasFocus() ? 2.2f : 1.3f));
        g2.drawRoundRect(1, 1, w - 6, h - 7, h - 6, h - 6);

        g2.dispose();
    }

    private static class CampoTexto extends JTextField {

        CampoTexto() {
            setOpaque(false);
            setFont(new Font("Segoe UI", Font.PLAIN, 15));
            setForeground(TEXTO);
            setCaretColor(VERDE_CLARO);
            setSelectionColor(VERDE);
            setSelectedTextColor(Color.WHITE);
            setBorder(new EmptyBorder(0, 20, 4, 20));
            setPreferredSize(new Dimension(300, 44));

            addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    repaint();
                }

                @Override
                public void focusLost(FocusEvent e) {
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            pintarCampo(g, this);
            super.paintComponent(g);
        }
    }

    private static class CampoClave extends JPasswordField {

        CampoClave() {
            setOpaque(false);
            setFont(new Font("Segoe UI", Font.PLAIN, 15));
            setForeground(TEXTO);
            setCaretColor(VERDE_CLARO);
            setSelectionColor(VERDE);
            setSelectedTextColor(Color.WHITE);
            setBorder(new EmptyBorder(0, 20, 4, 20));
            setPreferredSize(new Dimension(300, 44));

            addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    repaint();
                }

                @Override
                public void focusLost(FocusEvent e) {
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            pintarCampo(g, this);
            super.paintComponent(g);
        }
    }

    // Botón redondeado verde con efecto hover
    private static class BotonRedondo extends JButton {

        private boolean encima = false;

        BotonRedondo(String texto) {
            super(texto);

            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setForeground(Color.WHITE);
            setFont(new Font("Segoe UI", Font.BOLD, 16));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setPreferredSize(new Dimension(300, 48));

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    encima = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    encima = false;
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );
            g2.setRenderingHint(
                    RenderingHints.KEY_TEXT_ANTIALIASING,
                    RenderingHints.VALUE_TEXT_ANTIALIAS_ON
            );

            int w = getWidth();
            int h = getHeight();
            int desplazamiento = getModel().isPressed() ? 2 : 0;

            // Sombra
            g2.setColor(new Color(0, 0, 0, 90));
            g2.fillRoundRect(2, 5, w - 4, h - 6, h, h);

            // Cuerpo verde
            Color color = encima
                    ? new Color(95, 165, 92)
                    : VERDE;

            g2.setColor(color);
            g2.fillRoundRect(
                    0, desplazamiento, w - 4, h - 6, h, h
            );

            // Borde sutil
            g2.setColor(new Color(150, 205, 145, 90));
            g2.drawRoundRect(
                    0, desplazamiento, w - 5, h - 7, h, h
            );

            // Texto
            FontMetrics fm = g2.getFontMetrics();
            int x = (w - 4 - fm.stringWidth(getText())) / 2;
            int y = (h - 6 - fm.getHeight()) / 2
                    + fm.getAscent() + desplazamiento;

            g2.setColor(Color.WHITE);
            g2.drawString(getText(), x, y);

            g2.dispose();
        }
    }

    // Logo de audífonos y celular, adaptado a la paleta verde
    private static class LogoPanel extends JPanel {

        LogoPanel() {
            setOpaque(false);
            setPreferredSize(new Dimension(120, 120));
        }

        @Override
        protected void paintComponent(Graphics g) {

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            // Sombra del círculo
            g2.setColor(new Color(0, 0, 0, 85));
            g2.fillOval(10, 14, 100, 100);

            // Círculo verde
            g2.setColor(new Color(48, 95, 51));
            g2.fillOval(8, 6, 104, 104);

            // Aro exterior
            g2.setColor(VERDE_CLARO);
            g2.setStroke(new BasicStroke(3f));
            g2.drawOval(8, 6, 104, 104);

            g2.setColor(Color.WHITE);

            // Diadema de los audífonos
            g2.setStroke(new BasicStroke(
                    7f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND
            ));
            g2.drawArc(30, 24, 60, 58, 0, 180);

            // Almohadillas
            g2.fillRoundRect(23, 54, 16, 30, 10, 10);
            g2.fillRoundRect(81, 54, 16, 30, 10, 10);

            // Celular al centro
            g2.setStroke(new BasicStroke(3.5f));
            g2.drawRoundRect(47, 48, 26, 42, 8, 8);

            g2.setStroke(new BasicStroke(
                    2.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND
            ));
            g2.drawLine(55, 54, 65, 54);
            g2.fillOval(57, 80, 6, 6);

            g2.dispose();
        }
    }
}
