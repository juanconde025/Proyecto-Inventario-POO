/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

/**
 *
 * @author juanc
 */

import controlador.ProductoController;
import modelo.Usuario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class MenuPrincipalView extends JFrame {

    private Usuario usuario;

    private JTextField txtId;
    private JTextField txtCodigo;
    private JTextField txtNombre;
    private JTextField txtCategoria;
    private JTextField txtPrecio;
    private JTextField txtStock;
    private JTextField txtDescripcion;

    private JButton btnNuevo;
    private JButton btnGuardar;
    private JButton btnActualizar;
    private JButton btnEliminar;
    private JButton btnLimpiar;
    private JButton btnCerrarSesion;

    private JTable tablaProductos;
    private DefaultTableModel modeloTabla;

    public MenuPrincipalView(Usuario usuario) {

        this.usuario = usuario;

        setTitle("Nissi Accesorios - Panel Administrativo");

        setSize(1000, 650);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        inicializarComponentes();

        new ProductoController(this);
    }

    private void inicializarComponentes() {

        setLayout(new BorderLayout());

        // =========================================
        // ENCABEZADO
        // =========================================

        JPanel panelSuperior =
                new JPanel(new BorderLayout());

        JLabel lblTitulo =
                new JLabel("NISSI ACCESORIOS");

        lblTitulo.setFont(
                new Font("Arial", Font.BOLD, 24)
        );

        JLabel lblUsuario =
                new JLabel(
                        "Usuario: "
                        + usuario.getNombre()
                        + " | Rol: "
                        + usuario.getRol()
                );

        btnCerrarSesion =
                new JButton("Cerrar sesión");

        JPanel panelInfo =
                new JPanel(new FlowLayout(FlowLayout.RIGHT));

        panelInfo.add(lblUsuario);
        panelInfo.add(btnCerrarSesion);

        panelSuperior.add(
                lblTitulo,
                BorderLayout.WEST
        );

        panelSuperior.add(
                panelInfo,
                BorderLayout.EAST
        );

        add(
                panelSuperior,
                BorderLayout.NORTH
        );

        // =========================================
        // FORMULARIO
        // =========================================

        JPanel panelFormulario =
                new JPanel(
                        new GridLayout(8, 2, 8, 8)
                );

        panelFormulario.setBorder(
                BorderFactory.createTitledBorder(
                        "Datos del producto"
                )
        );

        txtId = new JTextField();
        txtId.setEditable(false);

        txtCodigo = new JTextField();
        txtNombre = new JTextField();
        txtCategoria = new JTextField();
        txtPrecio = new JTextField();
        txtStock = new JTextField();
        txtDescripcion = new JTextField();

        panelFormulario.add(
                new JLabel("ID:")
        );

        panelFormulario.add(txtId);

        panelFormulario.add(
                new JLabel("Código:")
        );

        panelFormulario.add(txtCodigo);

        panelFormulario.add(
                new JLabel("Nombre:")
        );

        panelFormulario.add(txtNombre);

        panelFormulario.add(
                new JLabel("Categoría:")
        );

        panelFormulario.add(txtCategoria);

        panelFormulario.add(
                new JLabel("Precio:")
        );

        panelFormulario.add(txtPrecio);

        panelFormulario.add(
                new JLabel("Stock:")
        );

        panelFormulario.add(txtStock);

        panelFormulario.add(
                new JLabel("Descripción:")
        );

        panelFormulario.add(txtDescripcion);

        JPanel panelBotones =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER
                        )
                );

        btnNuevo =
                new JButton("Nuevo");

        btnGuardar =
                new JButton("Guardar");

        btnActualizar =
                new JButton("Actualizar");

        btnEliminar =
                new JButton("Eliminar");

        btnLimpiar =
                new JButton("Limpiar");

        panelBotones.add(btnNuevo);
        panelBotones.add(btnGuardar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);

        JPanel panelIzquierdo =
                new JPanel(new BorderLayout());

        panelIzquierdo.setBorder(
                BorderFactory.createEmptyBorder(
                        10, 10, 10, 10
                )
        );

        panelIzquierdo.add(
                panelFormulario,
                BorderLayout.CENTER
        );

        panelIzquierdo.add(
                panelBotones,
                BorderLayout.SOUTH
        );

        add(
                panelIzquierdo,
                BorderLayout.WEST
        );

        // =========================================
        // TABLA
        // =========================================

        String[] columnas = {
            "ID",
            "Código",
            "Nombre",
            "Categoría",
            "Precio",
            "Stock",
            "Descripción"
        };

        modeloTabla =
                new DefaultTableModel(columnas, 0) {

                    @Override
                    public boolean isCellEditable(
                            int row,
                            int column) {

                        return false;
                    }
                };

        tablaProductos =
                new JTable(modeloTabla);

        tablaProductos.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        JScrollPane scroll =
                new JScrollPane(tablaProductos);

        scroll.setBorder(
                BorderFactory.createTitledBorder(
                        "Productos registrados"
                )
        );

        add(
                scroll,
                BorderLayout.CENTER
        );

        // =========================================
        // CERRAR SESIÓN
        // =========================================

        btnCerrarSesion.addActionListener(e -> {

            int respuesta =
                    JOptionPane.showConfirmDialog(
                            this,
                            "¿Desea cerrar la sesión?",
                            "Cerrar sesión",
                            JOptionPane.YES_NO_OPTION
                    );

            if (respuesta ==
                    JOptionPane.YES_OPTION) {

                dispose();

                LoginView login =
                        new LoginView();

                login.setVisible(true);
            }
        });
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public JTextField getTxtId() {
        return txtId;
    }

    public JTextField getTxtCodigo() {
        return txtCodigo;
    }

    public JTextField getTxtNombre() {
        return txtNombre;
    }

    public JTextField getTxtCategoria() {
        return txtCategoria;
    }

    public JTextField getTxtPrecio() {
        return txtPrecio;
    }

    public JTextField getTxtStock() {
        return txtStock;
    }

    public JTextField getTxtDescripcion() {
        return txtDescripcion;
    }

    public JButton getBtnNuevo() {
        return btnNuevo;
    }

    public JButton getBtnGuardar() {
        return btnGuardar;
    }

    public JButton getBtnActualizar() {
        return btnActualizar;
    }

    public JButton getBtnEliminar() {
        return btnEliminar;
    }

    public JButton getBtnLimpiar() {
        return btnLimpiar;
    }

    public JButton getBtnCerrarSesion() {
        return btnCerrarSesion;
    }

    public JTable getTablaProductos() {
        return tablaProductos;
    }

    public DefaultTableModel getModeloTabla() {
        return modeloTabla;
    }

    public void mostrarMensaje(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Nissi Accesorios",
                JOptionPane.INFORMATION_MESSAGE
        );
    }
}
