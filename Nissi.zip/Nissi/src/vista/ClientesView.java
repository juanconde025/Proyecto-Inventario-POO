/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

/**
 *
 * @author juanc
 */

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ClientesView extends JFrame {

    private JTextField txtId;
    private JTextField txtDocumento;
    private JTextField txtNombre;
    private JTextField txtTelefono;
    private JTextField txtCorreo;
    private JTextField txtDireccion;

    private JComboBox<String> cmbEstado;

    private JTable tabla;
    private DefaultTableModel modelo;

    private JButton btnNuevo;
    private JButton btnGuardar;
    private JButton btnActualizar;
    private JButton btnEliminar;
    private JButton btnCerrar;

    private JLabel lblInfo;

    private final Color FONDO = new Color(15, 23, 42);
    private final Color PANEL = new Color(30, 41, 59);
    private final Color VERDE = new Color(22, 101, 52);
    private final Color TEXTO = new Color(226, 232, 240);

    public ClientesView() {

        setTitle("Nissi Accesorios - Gestión de clientes");
        setSize(1200, 800);
        setMinimumSize(new Dimension(1100, 750));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        inicializar();
    }

    private void inicializar() {

        JPanel fondo = new JPanel(new BorderLayout(15, 15));
        fondo.setBackground(FONDO);
        fondo.setBorder(new EmptyBorder(22, 25, 22, 25));

        JLabel titulo = new JLabel("Gestión de clientes");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 26));
        titulo.setForeground(Color.WHITE);

        btnCerrar = boton("Cerrar", new Color(100, 116, 139));

        JPanel encabezado = new JPanel(new BorderLayout());
        encabezado.setOpaque(false);
        encabezado.add(titulo, BorderLayout.WEST);
        encabezado.add(btnCerrar, BorderLayout.EAST);

        btnCerrar.addActionListener(e -> dispose());

        fondo.add(encabezado, BorderLayout.NORTH);
        fondo.add(crearContenido(), BorderLayout.CENTER);

        setContentPane(fondo);
    }

    private JPanel crearContenido() {

        JPanel contenido = new JPanel(new BorderLayout(15, 0));
        contenido.setOpaque(false);

        contenido.add(crearFormulario(), BorderLayout.WEST);
        contenido.add(crearTabla(), BorderLayout.CENTER);

        return contenido;
    }

    private JPanel crearFormulario() {

        JPanel panel = tarjeta();
        panel.setPreferredSize(new Dimension(330, 20));
        panel.setLayout(new BorderLayout(0, 12));

        JLabel titulo = new JLabel("Datos del cliente");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 19));
        titulo.setForeground(Color.WHITE);

        panel.add(titulo, BorderLayout.NORTH);

        JPanel campos = new JPanel(new GridLayout(0, 1, 0, 5));
        campos.setOpaque(false);

        txtId = campo();
        txtId.setEditable(false);

        txtDocumento = campo();
        txtNombre = campo();
        txtTelefono = campo();
        txtCorreo = campo();
        txtDireccion = campo();

        cmbEstado = new JComboBox<>(new String[]{
            "ACTIVO", "INACTIVO"
        });

        cmbEstado.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        agregarCampo(campos, "ID", txtId);
        agregarCampo(campos, "Documento / NIT", txtDocumento);
        agregarCampo(campos, "Nombre / Razón social", txtNombre);
        agregarCampo(campos, "Teléfono", txtTelefono);
        agregarCampo(campos, "Correo electrónico", txtCorreo);
        agregarCampo(campos, "Dirección", txtDireccion);
        agregarCampo(campos, "Estado", cmbEstado);

        panel.add(campos, BorderLayout.CENTER);

        JPanel botones = new JPanel(new GridLayout(2, 2, 7, 7));
        botones.setOpaque(false);

        btnNuevo = boton("Nuevo", new Color(71, 85, 105));
        btnGuardar = boton("Guardar", VERDE);
        btnActualizar = boton("Actualizar", new Color(180, 130, 35));
        btnEliminar = boton("Desactivar", new Color(160, 45, 55));

        botones.add(btnNuevo);
        botones.add(btnGuardar);
        botones.add(btnActualizar);
        botones.add(btnEliminar);

        panel.add(botones, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel crearTabla() {

        JPanel panel = tarjeta();
        panel.setLayout(new BorderLayout(0, 12));

        JLabel titulo = new JLabel("Clientes registrados");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 19));
        titulo.setForeground(Color.WHITE);

        panel.add(titulo, BorderLayout.NORTH);

        modelo = new DefaultTableModel(
                new String[]{
                    "ID", "Documento", "Nombre",
                    "Teléfono", "Correo", "Estado"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };

        tabla = new JTable(modelo);
        tabla.setRowHeight(32);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tabla.setBackground(PANEL);
        tabla.setForeground(TEXTO);
        tabla.setSelectionBackground(VERDE);
        tabla.setSelectionForeground(Color.WHITE);
        tabla.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        tabla.getTableHeader().setFont(
                new Font("Segoe UI", Font.BOLD, 12)
        );
        tabla.getTableHeader().setBackground(VERDE);
        tabla.getTableHeader().setForeground(Color.WHITE);
        tabla.getTableHeader().setReorderingAllowed(false);

        int[] anchos = {40, 110, 180, 100, 180, 75};

        for (int i = 0; i < anchos.length; i++) {
            tabla.getColumnModel().getColumn(i)
                    .setPreferredWidth(anchos[i]);
        }

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.getViewport().setBackground(PANEL);

        panel.add(scroll, BorderLayout.CENTER);

        lblInfo = new JLabel("Selecciona un cliente para consultar sus datos.");
        lblInfo.setForeground(new Color(148, 163, 184));

        panel.add(lblInfo, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel tarjeta() {
        JPanel p = new JPanel();
        p.setBackground(PANEL);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(71, 85, 105)),
                new EmptyBorder(18, 18, 18, 18)
        ));
        return p;
    }

    private JTextField campo() {
        JTextField t = new JTextField();
        t.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        t.setForeground(TEXTO);
        t.setCaretColor(Color.WHITE);
        t.setBackground(new Color(42, 52, 68));
        t.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(71, 85, 105)),
                new EmptyBorder(7, 9, 7, 9)
        ));
        t.setPreferredSize(new Dimension(200, 64));
        return t;
    }

    private JButton boton(String texto, Color color) {
        JButton b = new JButton(texto);
        b.setFont(new Font("Segoe UI", Font.BOLD, 12));
        b.setForeground(Color.WHITE);
        b.setBackground(color);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(100, 38));
        return b;
    }

    private void agregarCampo(
            JPanel panel, String texto, JComponent componente) {

        JLabel etiqueta = new JLabel(texto);
        etiqueta.setForeground(TEXTO);
        etiqueta.setFont(new Font("Segoe UI", Font.BOLD, 12));

        panel.add(etiqueta);
        panel.add(componente);
    }

    public void limpiarFormulario() {
        txtId.setText("");
        txtDocumento.setText("");
        txtNombre.setText("");
        txtTelefono.setText("");
        txtCorreo.setText("");
        txtDireccion.setText("");
        cmbEstado.setSelectedItem("ACTIVO");
        tabla.clearSelection();
    }

    public void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Nissi Accesorios",
                JOptionPane.INFORMATION_MESSAGE);
    }

    public int confirmar(String mensaje) {
        return JOptionPane.showConfirmDialog(
                this, mensaje, "Confirmar",
                JOptionPane.YES_NO_OPTION
        );
    }

    public JTextField getTxtId() { return txtId; }
    public JTextField getTxtDocumento() { return txtDocumento; }
    public JTextField getTxtNombre() { return txtNombre; }
    public JTextField getTxtTelefono() { return txtTelefono; }
    public JTextField getTxtCorreo() { return txtCorreo; }
    public JTextField getTxtDireccion() { return txtDireccion; }

    public JComboBox<String> getCmbEstado() { return cmbEstado; }

    public JTable getTabla() { return tabla; }
    public DefaultTableModel getModelo() { return modelo; }

    public JButton getBtnNuevo() { return btnNuevo; }
    public JButton getBtnGuardar() { return btnGuardar; }
    public JButton getBtnActualizar() { return btnActualizar; }
    public JButton getBtnEliminar() { return btnEliminar; }

    public JLabel getLblInfo() { return lblInfo; }
}
