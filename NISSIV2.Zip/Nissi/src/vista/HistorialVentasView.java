package vista;

import dao.VentaDAO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.util.List;
import java.util.Locale;

public class HistorialVentasView extends JDialog {

    private final VentaDAO ventaDAO = new VentaDAO();
    private final Locale co = Locale.forLanguageTag("es-CO");

    private DefaultTableModel modelo;
    private JComboBox<String> cmbPeriodo;
    private JLabel lblHoy, lblSemana, lblMes, lblResumen;

    public HistorialVentasView(JFrame padre) {
        super(padre, "Historial de ventas", true);
        setSize(1000, 640);
        setLocationRelativeTo(padre);
        inicializar();
        cargar();
    }

    private void inicializar() {

        JPanel fondo = new JPanel(new BorderLayout(0, 14)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setPaint(new GradientPaint(0, 0, new Color(15, 32, 80),
                        getWidth(), getHeight(), new Color(95, 40, 150)));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        fondo.setBorder(new EmptyBorder(18, 24, 18, 24));

        // ---------- Superior ----------
        JLabel titulo = new JLabel("HISTORIAL DE VENTAS");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 26));
        titulo.setForeground(Color.WHITE);

        cmbPeriodo = new JComboBox<>(new String[]{
            "Hoy", "Últimos 7 días", "Este mes", "Todo"});
        cmbPeriodo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cmbPeriodo.addActionListener(e -> cargar());

        JLabel lblPeriodo = new JLabel("Mostrar:");
        lblPeriodo.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblPeriodo.setForeground(Color.WHITE);

        JPanel filtro = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        filtro.setOpaque(false);
        filtro.add(lblPeriodo);
        filtro.add(cmbPeriodo);

        JPanel fila1 = new JPanel(new BorderLayout());
        fila1.setOpaque(false);
        fila1.add(titulo, BorderLayout.WEST);
        fila1.add(filtro, BorderLayout.EAST);

        lblHoy = new JLabel("$ 0");
        lblSemana = new JLabel("$ 0");
        lblMes = new JLabel("$ 0");

        JPanel totales = new JPanel(new GridLayout(1, 3, 14, 0));
        totales.setOpaque(false);
        totales.add(tarjetaTotal("Vendido hoy", lblHoy));
        totales.add(tarjetaTotal("Últimos 7 días", lblSemana));
        totales.add(tarjetaTotal("Este mes", lblMes));

        JPanel superior = new JPanel(new BorderLayout(0, 12));
        superior.setOpaque(false);
        superior.add(fila1, BorderLayout.NORTH);
        superior.add(totales, BorderLayout.CENTER);

        // ---------- Tabla ----------
        modelo = new DefaultTableModel(new String[]{
            "N°", "Fecha", "Código", "Producto", "Cant.",
            "Precio unit.", "Total", "Vendedor"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        JTable tabla = new JTable(modelo) {
            @Override
            public Component prepareRenderer(TableCellRenderer r, int row, int col) {
                Component c = super.prepareRenderer(r, row, col);
                if (!isRowSelected(row)) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(238, 242, 252));
                }
                return c;
            }
        };
        tabla.setRowHeight(30);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tabla.setSelectionBackground(new Color(0, 170, 255));
        tabla.setShowVerticalLines(false);

        JTableHeader enc = tabla.getTableHeader();
        enc.setFont(new Font("Segoe UI", Font.BOLD, 14));
        enc.setBackground(new Color(60, 50, 150));
        enc.setForeground(Color.WHITE);
        enc.setPreferredSize(new Dimension(0, 36));
        enc.setReorderingAllowed(false);

        DefaultTableCellRenderer dinero = new DefaultTableCellRenderer() {
            @Override
            protected void setValue(Object v) {
                setText(String.format(co, "$ %,.0f", ((Number) v).doubleValue()));
                setHorizontalAlignment(RIGHT);
            }
        };
        tabla.getColumnModel().getColumn(5).setCellRenderer(dinero);
        tabla.getColumnModel().getColumn(6).setCellRenderer(dinero);

        int[] anchos = {50, 150, 80, 230, 60, 110, 110, 110};
        for (int i = 0; i < anchos.length; i++) {
            tabla.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
        }

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.getViewport().setBackground(Color.WHITE);

        // ---------- Inferior ----------
        lblResumen = new JLabel(" ");
        lblResumen.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblResumen.setForeground(new Color(120, 255, 200));

        MenuPrincipalView.Boton btnCerrar = new MenuPrincipalView.Boton("Cerrar",
                new Color(120, 130, 160), new Color(70, 80, 110), 110, 40);
        btnCerrar.addActionListener(e -> dispose());

        JPanel inferior = new JPanel(new BorderLayout());
        inferior.setOpaque(false);
        inferior.add(lblResumen, BorderLayout.WEST);
        inferior.add(btnCerrar, BorderLayout.EAST);

        fondo.add(superior, BorderLayout.NORTH);
        fondo.add(scroll, BorderLayout.CENTER);
        fondo.add(inferior, BorderLayout.SOUTH);
        setContentPane(fondo);
    }

    private JPanel tarjetaTotal(String texto, JLabel valor) {

        JPanel p = new JPanel(new GridLayout(2, 1)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 255, 255, 40));
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 28, 28);
                g2.setColor(new Color(255, 255, 255, 100));
                g2.drawRoundRect(0, 0, getWidth() - 2, getHeight() - 2, 28, 28);
                g2.dispose();
            }
        };
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(10, 18, 10, 18));

        JLabel t = new JLabel(texto);
        t.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        t.setForeground(new Color(190, 235, 255));

        valor.setFont(new Font("Segoe UI", Font.BOLD, 24));
        valor.setForeground(Color.WHITE);

        p.add(t);
        p.add(valor);
        return p;
    }

    private void cargar() {
        try {
            List<Object[]> filas = ventaDAO.listarVentas(cmbPeriodo.getSelectedIndex());

            modelo.setRowCount(0);
            int unidades = 0;
            double suma = 0;

            for (Object[] f : filas) {
                modelo.addRow(f);
                unidades += (Integer) f[4];
                suma += (Double) f[6];
            }

            double[] t = ventaDAO.totales();
            lblHoy.setText(String.format(co, "$ %,.0f", t[0]));
            lblSemana.setText(String.format(co, "$ %,.0f", t[1]));
            lblMes.setText(String.format(co, "$ %,.0f", t[2]));

            lblResumen.setText("Ventas: " + filas.size() + "   |   Unidades: "
                    + unidades + "   |   Total del período: "
                    + String.format(co, "$ %,.0f", suma));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error al cargar las ventas: " + e.getMessage());
        }
    }
}