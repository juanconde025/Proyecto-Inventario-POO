package vista;

import conexion.Respaldo;
import controlador.ProductoController;
import modelo.Usuario;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Locale;

public class MenuPrincipalView extends JFrame {

    private static final int STOCK_BAJO = 5;

    private final String nombreUsuario;
    private final String rolUsuario;

    private Campo txtId, txtCodigo, txtNombre, txtCategoria, txtPrecio, txtStock, txtDescripcion;
    private Boton btnNuevo, btnGuardar, btnActualizar, btnEliminar, btnLimpiar, btnVender;
    private Boton btnCerrarSesion;
    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private JLabel lblInfo;

    public MenuPrincipalView() {
        this("Administrador", "ADMIN");
    }

    public MenuPrincipalView(Usuario usuario) {
        this(usuario != null ? usuario.getNombre() : "Administrador",
             usuario != null ? usuario.getRol() : "ADMIN");
    }

    public MenuPrincipalView(String nombreUsuario, String rolUsuario) {
        this.nombreUsuario = nombreUsuario;
        this.rolUsuario = rolUsuario;

        setTitle("Nissi Accesorios - Panel Administrativo");
        setSize(1280, 720);
        setMinimumSize(new Dimension(1150, 650));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        inicializarComponentes();

        new ProductoController(this);

        SwingUtilities.invokeLater(this::avisarStockBajo);
    }

    private void inicializarComponentes() {

        JPanel fondo = new JPanel(new BorderLayout(0, 15)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0, 0, new Color(15, 32, 80),
                        getWidth(), getHeight(), new Color(95, 40, 150)));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(255, 255, 255, 14));
                g2.fillOval(-80, -80, 280, 280);
                g2.fillOval(getWidth() - 200, getHeight() - 220, 320, 320);
                g2.dispose();
            }
        };
        fondo.setBorder(new EmptyBorder(18, 28, 22, 28));

        fondo.add(crearEncabezado(), BorderLayout.NORTH);
        fondo.add(crearCuerpo(), BorderLayout.CENTER);

        SwingUtilities.invokeLater(() -> txtCodigo.requestFocusInWindow());

        setContentPane(fondo);
    }

    // ---------------- Encabezado ----------------
    private JPanel crearEncabezado() {

        JPanel encabezado = new JPanel(new BorderLayout(15, 0));
        encabezado.setOpaque(false);

        JPanel titulos = new JPanel(new GridLayout(2, 1));
        titulos.setOpaque(false);

        JLabel lblTitulo = new JLabel("NISSI ACCESORIOS");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitulo.setForeground(Color.WHITE);

        JLabel lblSub = new JLabel("Accesorios & Tecnología  |  Panel Administrativo");
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSub.setForeground(new Color(120, 220, 255));

        titulos.add(lblTitulo);
        titulos.add(lblSub);

        JPanel izquierda = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 0));
        izquierda.setOpaque(false);
        izquierda.add(new LogoMini());
        izquierda.add(titulos);

        JLabel lblUsuario = new JLabel("Usuario: " + nombreUsuario + "  |  Rol: " + rolUsuario);
        lblUsuario.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblUsuario.setForeground(Color.WHITE);

        btnCerrarSesion = new Boton("Cerrar sesión",
                new Color(240, 80, 100), new Color(180, 30, 90), 140, 38);
        btnCerrarSesion.addActionListener(e -> {
            dispose();
            new LoginView().setVisible(true);
        });

        Boton btnHistorial = new Boton("Historial",
                new Color(0, 190, 255), new Color(80, 60, 220), 110, 38);
        btnHistorial.addActionListener(e -> new HistorialVentasView(this).setVisible(true));

        Boton btnRespaldo = new Boton("Respaldo",
                new Color(60, 210, 130), new Color(0, 150, 110), 110, 38);
        btnRespaldo.addActionListener(e -> Respaldo.crearCopia(this));

        JPanel derecha = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 12));
        derecha.setOpaque(false);
        derecha.add(lblUsuario);
        derecha.add(btnHistorial);
        derecha.add(btnRespaldo);
        derecha.add(btnCerrarSesion);

        encabezado.add(izquierda, BorderLayout.WEST);
        encabezado.add(derecha, BorderLayout.EAST);
        return encabezado;
    }

    // ---------------- Cuerpo: formulario + tabla ----------------
    private JPanel crearCuerpo() {

        JPanel cuerpo = new JPanel(new GridBagLayout());
        cuerpo.setOpaque(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1;
        gbc.gridy = 0;

        gbc.gridx = 0;
        gbc.weightx = 0.36;
        gbc.insets = new Insets(0, 0, 0, 14);
        cuerpo.add(crearTarjetaFormulario(), gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.64;
        gbc.insets = new Insets(0, 0, 0, 0);
        cuerpo.add(crearTarjetaTabla(), gbc);

        return cuerpo;
    }

    private JPanel crearTarjetaFormulario() {

        Tarjeta tarjeta = new Tarjeta(new BorderLayout(0, 12));

        JLabel titulo = new JLabel("Datos del producto");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titulo.setForeground(Color.WHITE);
        tarjeta.add(titulo, BorderLayout.NORTH);

        txtId = new Campo();
        txtId.setEditable(false);
        txtCodigo = new Campo();
        txtNombre = new Campo();
        txtCategoria = new Campo();
        txtPrecio = new Campo();
        txtStock = new Campo();
        txtDescripcion = new Campo();

        String[] etiquetas = {"ID", "Código", "Nombre", "Categoría",
            "Precio", "Stock", "Descripción"};
        Campo[] campos = {txtId, txtCodigo, txtNombre, txtCategoria,
            txtPrecio, txtStock, txtDescripcion};

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;

        for (int i = 0; i < etiquetas.length; i++) {
            JLabel l = new JLabel(etiquetas[i]);
            l.setFont(new Font("Segoe UI", Font.BOLD, 14));
            l.setForeground(Color.WHITE);

            gbc.gridy = i;
            gbc.gridx = 0;
            gbc.weightx = 0;
            gbc.insets = new Insets(6, 0, 6, 12);
            form.add(l, gbc);

            gbc.gridx = 1;
            gbc.weightx = 1;
            gbc.insets = new Insets(6, 0, 6, 0);
            form.add(campos[i], gbc);
        }
        tarjeta.add(form, BorderLayout.CENTER);

        btnNuevo = new Boton("Nuevo", new Color(0, 190, 255), new Color(80, 60, 220), 100, 42);
        btnGuardar = new Boton("Guardar", new Color(60, 210, 130), new Color(0, 150, 110), 100, 42);
        btnActualizar = new Boton("Actualizar", new Color(255, 190, 40), new Color(235, 120, 20), 100, 42);
        btnEliminar = new Boton("Eliminar", new Color(240, 80, 100), new Color(180, 30, 90), 100, 42);
        btnLimpiar = new Boton("Limpiar", new Color(120, 130, 160), new Color(70, 80, 110), 100, 42);
        btnVender = new Boton("Vender", new Color(170, 90, 255), new Color(110, 40, 200), 100, 42);

        JPanel botones = new JPanel(new GridLayout(2, 3, 10, 6));
        botones.setOpaque(false);
        botones.add(btnNuevo);
        botones.add(btnGuardar);
        botones.add(btnActualizar);
        botones.add(btnEliminar);
        botones.add(btnLimpiar);
        botones.add(btnVender);
        tarjeta.add(botones, BorderLayout.SOUTH);

        return tarjeta;
    }

    private JPanel crearTarjetaTabla() {

        Tarjeta tarjeta = new Tarjeta(new BorderLayout(0, 12));

        JLabel titulo = new JLabel("Productos registrados");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titulo.setForeground(Color.WHITE);
        tarjeta.add(titulo, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(new String[]{
            "ID", "Código", "Nombre", "Categoría", "Precio", "Stock", "Descripción"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabla = new JTable(modeloTabla) {
            @Override
            public Component prepareRenderer(TableCellRenderer r, int row, int col) {
                Component c = super.prepareRenderer(r, row, col);
                if (!isRowSelected(row)) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(238, 242, 252));
                }
                return c;
            }
        };
        tabla.setRowHeight(32);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tabla.setSelectionBackground(new Color(0, 170, 255));
        tabla.setSelectionForeground(Color.WHITE);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setShowVerticalLines(false);
        tabla.setGridColor(new Color(225, 230, 242));
        tabla.setIntercellSpacing(new Dimension(0, 1));

        JTableHeader encabezado = tabla.getTableHeader();
        encabezado.setFont(new Font("Segoe UI", Font.BOLD, 14));
        encabezado.setBackground(new Color(60, 50, 150));
        encabezado.setForeground(Color.WHITE);
        encabezado.setPreferredSize(new Dimension(0, 38));
        encabezado.setReorderingAllowed(false);

        // La columna ID se oculta de la vista pero sigue en el modelo
        tabla.removeColumn(tabla.getColumnModel().getColumn(0));

        final Locale co = Locale.forLanguageTag("es-CO");

        tabla.getColumn("Precio").setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            protected void setValue(Object v) {
                try {
                    setText(String.format(co, "$ %,.0f", Double.parseDouble(String.valueOf(v))));
                } catch (Exception e) {
                    super.setValue(v);
                }
                setHorizontalAlignment(RIGHT);
            }
        });

        tabla.getColumn("Stock").setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foco, int fila, int col) {
                Component c = super.getTableCellRendererComponent(t, v, sel, foco, fila, col);
                setHorizontalAlignment(CENTER);
                int stock = 0;
                try {
                    stock = Integer.parseInt(String.valueOf(v));
                } catch (NumberFormatException ignorado) {
                }
                boolean bajo = stock <= STOCK_BAJO;
                if (!sel) {
                    c.setForeground(bajo ? new Color(210, 30, 60) : Color.BLACK);
                }
                c.setFont(c.getFont().deriveFont(bajo ? Font.BOLD : Font.PLAIN));
                return c;
            }
        });

        tabla.getColumn("Código").setPreferredWidth(80);
        tabla.getColumn("Nombre").setPreferredWidth(170);
        tabla.getColumn("Categoría").setPreferredWidth(110);
        tabla.getColumn("Precio").setPreferredWidth(130);
        tabla.getColumn("Stock").setPreferredWidth(60);
        tabla.getColumn("Descripción").setPreferredWidth(240);

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 120), 2));
        scroll.getViewport().setBackground(Color.WHITE);
        tarjeta.add(scroll, BorderLayout.CENTER);

        lblInfo = new JLabel(" ");
        lblInfo.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblInfo.setForeground(new Color(120, 255, 200));

        JLabel nota = new JLabel("Las cantidades en rojo indican stock bajo (" + STOCK_BAJO + " o menos).");
        nota.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        nota.setForeground(new Color(190, 235, 255));

        JPanel pie = new JPanel(new GridLayout(2, 1, 0, 4));
        pie.setOpaque(false);
        pie.add(lblInfo);
        pie.add(nota);
        tarjeta.add(pie, BorderLayout.SOUTH);

        return tarjeta;
    }

    // ---------------- Alerta de stock bajo ----------------
    private void avisarStockBajo() {

        StringBuilder lista = new StringBuilder();
        int cantidad = 0;

        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            int stock = Integer.parseInt(modeloTabla.getValueAt(i, 5).toString());
            if (stock <= STOCK_BAJO) {
                cantidad++;
                if (cantidad <= 10) {
                    lista.append("• ")
                         .append(modeloTabla.getValueAt(i, 2))
                         .append(": ")
                         .append(stock)
                         .append(stock == 1 ? " unidad\n" : " unidades\n");
                }
            }
        }

        if (cantidad == 0) {
            return;
        }
        if (cantidad > 10) {
            lista.append("... y ").append(cantidad - 10).append(" más.\n");
        }

        JOptionPane.showMessageDialog(this,
                "Estos productos se están acabando:\n\n" + lista
                        + "\nConviene reabastecerlos pronto.",
                "Stock bajo", JOptionPane.WARNING_MESSAGE);
    }

    // ---------------- Métodos que usa el controlador ----------------
    public JTextField getTxtId() { return txtId; }
    public JTextField getTxtCodigo() { return txtCodigo; }
    public JTextField getTxtNombre() { return txtNombre; }
    public JTextField getTxtCategoria() { return txtCategoria; }
    public JTextField getTxtPrecio() { return txtPrecio; }
    public JTextField getTxtStock() { return txtStock; }
    public JTextField getTxtDescripcion() { return txtDescripcion; }

    public JButton getBtnNuevo() { return btnNuevo; }
    public JButton getBtnGuardar() { return btnGuardar; }
    public JButton getBtnActualizar() { return btnActualizar; }
    public JButton getBtnEliminar() { return btnEliminar; }
    public JButton getBtnLimpiar() { return btnLimpiar; }
    public JButton getBtnVender() { return btnVender; }
    public JButton getBtnCerrarSesion() { return btnCerrarSesion; }

    public String getNombreUsuario() { return nombreUsuario; }

    public JTable getTablaProductos() { return tabla; }
    public DefaultTableModel getModeloTabla() { return modeloTabla; }

    public void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Nissi Accesorios",
                JOptionPane.INFORMATION_MESSAGE);
    }

    public void mostrarInfo(String texto) {
        lblInfo.setText(texto);
    }

    // ==================================================
    // Tarjeta de cristal
    // ==================================================
    private static class Tarjeta extends JPanel {

        Tarjeta(LayoutManager lm) {
            super(lm);
            setOpaque(false);
            setBorder(new EmptyBorder(18, 20, 22, 28));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(0, 0, 0, 70));
            g2.fillRoundRect(6, 8, getWidth() - 12, getHeight() - 12, 40, 40);
            g2.setColor(new Color(255, 255, 255, 38));
            g2.fillRoundRect(0, 0, getWidth() - 8, getHeight() - 8, 40, 40);
            g2.setColor(new Color(255, 255, 255, 90));
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawRoundRect(0, 0, getWidth() - 9, getHeight() - 9, 40, 40);
            g2.dispose();
        }
    }

    // ==================================================
    // Campo redondeado con efecto 3D
    // ==================================================
    private static class Campo extends JTextField {

        Campo() {
            setOpaque(false);
            setFont(new Font("Segoe UI", Font.PLAIN, 15));
            setForeground(new Color(30, 30, 50));
            setCaretColor(new Color(0, 120, 220));
            setBorder(new EmptyBorder(0, 18, 4, 18));
            setPreferredSize(new Dimension(200, 40));
            addFocusListener(new FocusAdapter() {
                @Override public void focusGained(FocusEvent e) { repaint(); }
                @Override public void focusLost(FocusEvent e) { repaint(); }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();

            g2.setColor(new Color(0, 0, 0, 70));
            g2.fillRoundRect(2, 4, w - 4, h - 4, h, h);

            if (isEditable()) {
                g2.setPaint(new GradientPaint(0, 0, Color.WHITE,
                        0, h, new Color(225, 230, 242)));
            } else {
                g2.setPaint(new GradientPaint(0, 0, new Color(200, 205, 220),
                        0, h, new Color(170, 178, 200)));
            }
            g2.fillRoundRect(0, 0, w - 4, h - 5, h - 5, h - 5);

            g2.setColor(hasFocus() ? new Color(0, 170, 255) : new Color(170, 180, 205));
            g2.setStroke(new BasicStroke(hasFocus() ? 2.2f : 1.4f));
            g2.drawRoundRect(1, 1, w - 6, h - 7, h - 6, h - 6);

            g2.dispose();
            super.paintComponent(g);
        }
    }

    // ==================================================
    // Botón redondeado con degradado (lo usa también el historial)
    // ==================================================
    static class Boton extends JButton {

        private final Color c1, c2;
        private boolean encima = false;

        Boton(String texto, Color c1, Color c2, int ancho, int alto) {
            super(texto);
            this.c1 = c1;
            this.c2 = c2;
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setForeground(Color.WHITE);
            setFont(new Font("Segoe UI", Font.BOLD, 14));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setPreferredSize(new Dimension(ancho, alto));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { encima = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { encima = false; repaint(); }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                    RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            int d = getModel().isPressed() ? 2 : 0;

            g2.setColor(new Color(0, 0, 0, 90));
            g2.fillRoundRect(2, 5, w - 4, h - 6, h, h);

            Color a = encima ? c1.brighter() : c1;
            Color b = encima ? c2.brighter() : c2;
            g2.setPaint(new GradientPaint(0, 0, a, w, 0, b));
            g2.fillRoundRect(0, d, w - 4, h - 6, h, h);

            g2.setColor(new Color(255, 255, 255, 60));
            g2.fillRoundRect(6, d + 2, w - 16, (h - 6) / 2, h, h);

            FontMetrics fm = g2.getFontMetrics();
            int x = (w - 4 - fm.stringWidth(getText())) / 2;
            int y = (h - 6 - fm.getHeight()) / 2 + fm.getAscent() + d;
            g2.setColor(Color.WHITE);
            g2.drawString(getText(), x, y);
            g2.dispose();
        }
    }

    // ==================================================
    // Logo pequeño: audífonos + celular
    // ==================================================
    private static class LogoMini extends JPanel {

        LogoMini() {
            setOpaque(false);
            setPreferredSize(new Dimension(72, 72));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            g2.scale(0.6, 0.6);

            g2.setColor(new Color(0, 0, 0, 80));
            g2.fillOval(10, 14, 100, 100);
            g2.setPaint(new GradientPaint(10, 5, new Color(0, 210, 255),
                    110, 105, new Color(130, 70, 255)));
            g2.fillOval(8, 6, 104, 104);
            g2.setColor(new Color(255, 255, 255, 170));
            g2.setStroke(new BasicStroke(3f));
            g2.drawOval(8, 6, 104, 104);

            g2.setColor(Color.WHITE);
            g2.setStroke(new BasicStroke(7f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.drawArc(30, 24, 60, 58, 0, 180);
            g2.fillRoundRect(23, 54, 16, 30, 10, 10);
            g2.fillRoundRect(81, 54, 16, 30, 10, 10);
            g2.setStroke(new BasicStroke(3.5f));
            g2.drawRoundRect(47, 48, 26, 42, 8, 8);
            g2.setStroke(new BasicStroke(2.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.drawLine(55, 54, 65, 54);
            g2.fillOval(57, 80, 6, 6);

            g2.dispose();
        }
    }
}
