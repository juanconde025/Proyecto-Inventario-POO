package vista;

import controlador.LoginController;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LoginView extends JFrame {

    private CampoTexto txtUsuario;
    private CampoClave txtPassword;
    private BotonRedondo btnIngresar;

    public LoginView() {

        setTitle("Nissi Accesorios - Inicio de Sesión");
        setSize(440, 640);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        inicializarComponentes();

        getRootPane().setDefaultButton(btnIngresar);

        new LoginController(this);
    }

    private void inicializarComponentes() {

        // Fondo con degradado
        JPanel fondo = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_RENDERING,
                        RenderingHints.VALUE_RENDER_QUALITY);
                g2.setPaint(new GradientPaint(0, 0, new Color(15, 32, 80),
                        getWidth(), getHeight(), new Color(95, 40, 150)));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };

        // Tarjeta central
        JPanel tarjeta = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0, 0, 0, 70));
                g2.fillRoundRect(6, 8, getWidth() - 12, getHeight() - 12, 40, 40);
                g2.setColor(new Color(255, 255, 255, 38));
                g2.fillRoundRect(0, 0, getWidth() - 8, getHeight() - 8, 40, 40);
                g2.setColor(new Color(255, 255, 255, 90));
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(0, 0, getWidth() - 9, getHeight() - 9, 40, 40);
                g2.dispose();
            }
        };
        tarjeta.setOpaque(false);
        tarjeta.setBorder(new EmptyBorder(30, 35, 35, 43));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 0, 5, 0);

        // Logo
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.NONE;
        tarjeta.add(new LogoPanel(), gbc);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel lblTitulo = new JLabel("NISSI ACCESORIOS", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblTitulo.setForeground(Color.WHITE);
        gbc.gridy = 1;
        gbc.insets = new Insets(10, 0, 0, 0);
        tarjeta.add(lblTitulo, gbc);

        JLabel lblSub = new JLabel("Accesorios & Tecnología", SwingConstants.CENTER);
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSub.setForeground(new Color(120, 220, 255));
        gbc.gridy = 2;
        gbc.insets = new Insets(0, 0, 25, 0);
        tarjeta.add(lblSub, gbc);

        // Usuario
        JLabel lblUsuario = new JLabel("Usuario");
        lblUsuario.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblUsuario.setForeground(Color.WHITE);
        gbc.gridy = 3;
        gbc.insets = new Insets(5, 8, 3, 0);
        tarjeta.add(lblUsuario, gbc);

        txtUsuario = new CampoTexto();
        gbc.gridy = 4;
        gbc.insets = new Insets(0, 0, 12, 0);
        tarjeta.add(txtUsuario, gbc);

        // Contraseña
        JLabel lblPassword = new JLabel("Contraseña");
        lblPassword.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblPassword.setForeground(Color.WHITE);
        gbc.gridy = 5;
        gbc.insets = new Insets(5, 8, 3, 0);
        tarjeta.add(lblPassword, gbc);

        txtPassword = new CampoClave();
        gbc.gridy = 6;
        gbc.insets = new Insets(0, 0, 25, 0);
        tarjeta.add(txtPassword, gbc);

        // Botón
        btnIngresar = new BotonRedondo("INGRESAR");
        gbc.gridy = 7;
        gbc.insets = new Insets(0, 0, 0, 0);
        tarjeta.add(btnIngresar, gbc);

        fondo.add(tarjeta);
        setContentPane(fondo);
    }

    public JTextField getTxtUsuario() {
        return txtUsuario;
    }

    public JPasswordField getTxtPassword() {
        return txtPassword;
    }

    public JButton getBtnIngresar() {
        return btnIngresar;
    }

    public void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Nissi Accesorios",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    // ==================================================
    // Pinta un campo redondeado con efecto 3D
    // ==================================================
    private static void pintarCampo(Graphics g, JComponent c) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        int w = c.getWidth();
        int h = c.getHeight();

        // Sombra
        g2.setColor(new Color(0, 0, 0, 70));
        g2.fillRoundRect(2, 4, w - 4, h - 4, h, h);

        // Cuerpo con degradado
        g2.setPaint(new GradientPaint(0, 0, Color.WHITE,
                0, h, new Color(225, 230, 242)));
        g2.fillRoundRect(0, 0, w - 4, h - 5, h - 5, h - 5);

        // Borde (cambia al tener el foco)
        g2.setColor(c.hasFocus() ? new Color(0, 170, 255)
                : new Color(170, 180, 205));
        g2.setStroke(new BasicStroke(c.hasFocus() ? 2.2f : 1.4f));
        g2.drawRoundRect(1, 1, w - 6, h - 7, h - 6, h - 6);

        g2.dispose();
    }

    private static class CampoTexto extends JTextField {
        CampoTexto() {
            setOpaque(false);
            setFont(new Font("Segoe UI", Font.PLAIN, 15));
            setForeground(new Color(30, 30, 50));
            setCaretColor(new Color(0, 120, 220));
            setBorder(new EmptyBorder(0, 20, 4, 20));
            setPreferredSize(new Dimension(300, 44));
            addFocusListener(new FocusAdapter() {
                @Override public void focusGained(FocusEvent e) { repaint(); }
                @Override public void focusLost(FocusEvent e) { repaint(); }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            pintarCampo(g, this);
            super.paintComponent(g);
        }
    }

    private static class CampoClave extends JPasswordField {
        CampoClave() {
            setOpaque(false);
            setFont(new Font("Segoe UI", Font.PLAIN, 15));
            setForeground(new Color(30, 30, 50));
            setCaretColor(new Color(0, 120, 220));
            setBorder(new EmptyBorder(0, 20, 4, 20));
            setPreferredSize(new Dimension(300, 44));
            addFocusListener(new FocusAdapter() {
                @Override public void focusGained(FocusEvent e) { repaint(); }
                @Override public void focusLost(FocusEvent e) { repaint(); }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            pintarCampo(g, this);
            super.paintComponent(g);
        }
    }

    // ==================================================
    // Botón redondeado con degradado y efecto hover
    // ==================================================
    private static class BotonRedondo extends JButton {

        private boolean encima = false;

        BotonRedondo(String texto) {
            super(texto);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setForeground(Color.WHITE);
            setFont(new Font("Segoe UI", Font.BOLD, 16));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setPreferredSize(new Dimension(300, 48));

            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) {
                    encima = true; repaint();
                }
                @Override public void mouseExited(MouseEvent e) {
                    encima = false; repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                    RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();
            int desplazamiento = getModel().isPressed() ? 2 : 0;

            // Sombra
            g2.setColor(new Color(0, 0, 0, 90));
            g2.fillRoundRect(2, 5, w - 4, h - 6, h, h);

            // Cuerpo
            Color c1 = encima ? new Color(60, 220, 255) : new Color(0, 190, 255);
            Color c2 = encima ? new Color(110, 90, 255) : new Color(80, 60, 220);
            g2.setPaint(new GradientPaint(0, 0, c1, w, 0, c2));
            g2.fillRoundRect(0, desplazamiento, w - 4, h - 6, h, h);

            // Brillo superior
            g2.setColor(new Color(255, 255, 255, 60));
            g2.fillRoundRect(6, desplazamiento + 2, w - 16, (h - 6) / 2, h, h);

            // Texto
            FontMetrics fm = g2.getFontMetrics();
            int x = (w - 4 - fm.stringWidth(getText())) / 2;
            int y = (h - 6 - fm.getHeight()) / 2 + fm.getAscent() + desplazamiento;
            g2.setColor(Color.WHITE);
            g2.drawString(getText(), x, y);

            g2.dispose();
        }
    }

    // ==================================================
    // Logo: audífonos + celular (tecnología y accesorios)
    // ==================================================
    private static class LogoPanel extends JPanel {

        LogoPanel() {
            setOpaque(false);
            setPreferredSize(new Dimension(120, 120));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);

            // Sombra del círculo
            g2.setColor(new Color(0, 0, 0, 80));
            g2.fillOval(10, 14, 100, 100);

            // Círculo con degradado
            g2.setPaint(new GradientPaint(10, 5, new Color(0, 210, 255),
                    110, 105, new Color(130, 70, 255)));
            g2.fillOval(8, 6, 104, 104);

            // Aro exterior
            g2.setColor(new Color(255, 255, 255, 170));
            g2.setStroke(new BasicStroke(3f));
            g2.drawOval(8, 6, 104, 104);

            g2.setColor(Color.WHITE);

            // Diadema de los audífonos
            g2.setStroke(new BasicStroke(7f, BasicStroke.CAP_ROUND,
                    BasicStroke.JOIN_ROUND));
            g2.drawArc(30, 24, 60, 58, 0, 180);

            // Almohadillas
            g2.fillRoundRect(23, 54, 16, 30, 10, 10);
            g2.fillRoundRect(81, 54, 16, 30, 10, 10);

            // Celular al centro
            g2.setStroke(new BasicStroke(3.5f));
            g2.drawRoundRect(47, 48, 26, 42, 8, 8);
            g2.setStroke(new BasicStroke(2.5f, BasicStroke.CAP_ROUND,
                    BasicStroke.JOIN_ROUND));
            g2.drawLine(55, 54, 65, 54);
            g2.fillOval(57, 80, 6, 6);

            g2.dispose();
        }
    }
}