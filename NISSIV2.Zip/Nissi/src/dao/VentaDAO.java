package dao;

import conexion.Conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VentaDAO {

    // Registra la venta y descuenta el stock. Devuelve el total de la venta.
    public double registrarVenta(int idProducto, int cantidad, String usuario)
            throws SQLException {

        String sqlDescontar = """
                UPDATE productos
                SET stock = stock - ?
                WHERE id_producto = ? AND stock >= ?
                """;

        String sqlDatos = """
                SELECT codigo, nombre, precio
                FROM productos
                WHERE id_producto = ?
                """;

        String sqlVenta = """
                INSERT INTO ventas
                (id_producto, codigo, nombre, cantidad, precio_unitario, total, usuario)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """;

        try (Connection con = Conexion.conectar()) {

            con.setAutoCommit(false);

            try {
                // 1. Descontar stock (solo si alcanza)
                try (PreparedStatement ps = con.prepareStatement(sqlDescontar)) {
                    ps.setInt(1, cantidad);
                    ps.setInt(2, idProducto);
                    ps.setInt(3, cantidad);

                    if (ps.executeUpdate() == 0) {
                        throw new IllegalStateException(
                                "Stock insuficiente para esa cantidad.");
                    }
                }

                // 2. Leer datos del producto
                String codigo;
                String nombre;
                double precio;

                try (PreparedStatement ps = con.prepareStatement(sqlDatos)) {
                    ps.setInt(1, idProducto);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            throw new IllegalStateException("El producto ya no existe.");
                        }
                        codigo = rs.getString("codigo");
                        nombre = rs.getString("nombre");
                        precio = rs.getDouble("precio");
                    }
                }

                // 3. Guardar la venta
                double total = precio * cantidad;

                try (PreparedStatement ps = con.prepareStatement(sqlVenta)) {
                    ps.setInt(1, idProducto);
                    ps.setString(2, codigo);
                    ps.setString(3, nombre);
                    ps.setInt(4, cantidad);
                    ps.setDouble(5, precio);
                    ps.setDouble(6, total);
                    ps.setString(7, usuario);
                    ps.executeUpdate();
                }

                con.commit();
                return total;

            } catch (SQLException | RuntimeException e) {
                con.rollback();
                throw e;
            }
        }
    }

    // periodo: 0 = hoy, 1 = últimos 7 días, 2 = este mes, 3 = todo
    public List<Object[]> listarVentas(int periodo) throws SQLException {

        String filtro;
        switch (periodo) {
            case 0:
                filtro = "WHERE date(fecha) = date('now','localtime')";
                break;
            case 1:
                filtro = "WHERE date(fecha) >= date('now','localtime','-6 days')";
                break;
            case 2:
                filtro = "WHERE strftime('%Y-%m', fecha) = strftime('%Y-%m','now','localtime')";
                break;
            default:
                filtro = "";
        }

        String sql = "SELECT id_venta, fecha, codigo, nombre, cantidad, "
                + "precio_unitario, total, usuario FROM ventas "
                + filtro + " ORDER BY id_venta DESC";

        List<Object[]> filas = new ArrayList<>();

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                filas.add(new Object[]{
                    rs.getInt("id_venta"),
                    rs.getString("fecha"),
                    rs.getString("codigo"),
                    rs.getString("nombre"),
                    rs.getInt("cantidad"),
                    rs.getDouble("precio_unitario"),
                    rs.getDouble("total"),
                    rs.getString("usuario")
                });
            }
        }
        return filas;
    }

    // Devuelve {hoy, últimos 7 días, este mes}
    public double[] totales() throws SQLException {

        String sql = """
                SELECT
                  COALESCE(SUM(CASE WHEN date(fecha) = date('now','localtime')
                                    THEN total END), 0),
                  COALESCE(SUM(CASE WHEN date(fecha) >= date('now','localtime','-6 days')
                                    THEN total END), 0),
                  COALESCE(SUM(CASE WHEN strftime('%Y-%m', fecha) = strftime('%Y-%m','now','localtime')
                                    THEN total END), 0)
                FROM ventas
                """;

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            rs.next();
            return new double[]{rs.getDouble(1), rs.getDouble(2), rs.getDouble(3)};
        }
    }
}
