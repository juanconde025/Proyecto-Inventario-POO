package conexion;

import javax.swing.*;
import java.awt.Component;
import java.io.File;
import java.sql.Connection;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Respaldo {

    public static void crearCopia(Component padre) {

        JFileChooser selector = new JFileChooser();
        selector.setDialogTitle("Elija la carpeta donde guardar la copia de seguridad");
        selector.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        if (selector.showSaveDialog(padre) != JFileChooser.APPROVE_OPTION) {
            return;
        }

        String marca = new SimpleDateFormat("yyyy-MM-dd_HH-mm").format(new Date());
        File destino = new File(selector.getSelectedFile(),
                "nissi_accesorios_" + marca + ".db");

        try (Connection con = Conexion.conectar();
             Statement st = con.createStatement()) {

            // VACUUM INTO genera una copia completa y consistente
            st.execute("VACUUM INTO '"
                    + destino.getAbsolutePath().replace("'", "''") + "'");

            JOptionPane.showMessageDialog(padre,
                    "Copia de seguridad creada:\n" + destino.getAbsolutePath(),
                    "Nissi Accesorios", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(padre,
                    "No se pudo crear la copia: " + e.getMessage(),
                    "Nissi Accesorios", JOptionPane.ERROR_MESSAGE);
        }
    }
}
