package controlador;

import dao.ProductoDAO;
import dao.VentaDAO;
import modelo.Producto;
import vista.MenuPrincipalView;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import java.util.Locale;

public class ProductoController {

    private MenuPrincipalView vista;
    private ProductoDAO productoDAO;
    private VentaDAO ventaDAO = new VentaDAO();

    public ProductoController(MenuPrincipalView vista) {

        this.vista = vista;
        this.productoDAO = new ProductoDAO();

        cargarProductos();

        vista.getBtnNuevo().addActionListener(e -> limpiarFormulario());
        vista.getBtnGuardar().addActionListener(e -> guardarProducto());
        vista.getBtnActualizar().addActionListener(e -> actualizarProducto());
        vista.getBtnEliminar().addActionListener(e -> eliminarProducto());
        vista.getBtnLimpiar().addActionListener(e -> limpiarFormulario());
        vista.getBtnVender().addActionListener(e -> venderProducto());

        vista.getTablaProductos().getSelectionModel()
                .addListSelectionListener(e -> cargarSeleccion());
    }

    private void cargarProductos() {

        List<Producto> productos = productoDAO.listar();

        DefaultTableModel modelo = vista.getModeloTabla();

        modelo.setRowCount(0);

        for (Producto p : productos) {

            modelo.addRow(new Object[]{
                    p.getIdProducto(),
                    p.getCodigo(),
                    p.getNombre(),
                    p.getCategoria(),
                    p.getPrecio(),
                    p.getStock(),
                    p.getDescripcion()
            });
        }

        mostrarResumenGeneral();
    }

    private void guardarProducto() {

        try {

            Producto producto = obtenerProductoFormulario();

            if (producto == null) {
                return;
            }

            if (productoDAO.insertar(producto)) {

                vista.mostrarMensaje("Producto registrado correctamente.");

                cargarProductos();
                limpiarFormulario();

            } else {

                vista.mostrarMensaje("No fue posible registrar el producto. "
                        + "Revise que el código no esté repetido.");
            }

        } catch (Exception e) {

            vista.mostrarMensaje("Error: " + e.getMessage());
        }
    }

    private void actualizarProducto() {

        int fila = vista.getTablaProductos().getSelectedRow();

        if (fila == -1) {

            vista.mostrarMensaje("Seleccione un producto de la tabla.");

            return;
        }

        try {

            Producto producto = obtenerProductoFormulario();

            if (producto == null) {
                return;
            }

            int id = Integer.parseInt(vista.getTxtId().getText());

            producto.setIdProducto(id);

            if (productoDAO.actualizar(producto)) {

                vista.mostrarMensaje("Producto actualizado correctamente.");

                cargarProductos();
                limpiarFormulario();

            } else {

                vista.mostrarMensaje("No fue posible actualizar el producto.");
            }

        } catch (Exception e) {

            vista.mostrarMensaje("Error: " + e.getMessage());
        }
    }

    private void eliminarProducto() {

        int fila = vista.getTablaProductos().getSelectedRow();

        if (fila == -1) {

            vista.mostrarMensaje("Seleccione un producto.");

            return;
        }

        int id = Integer.parseInt(vista.getTxtId().getText());

        int confirmacion = JOptionPane.showConfirmDialog(
                vista,
                "¿Desea eliminar este producto?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION
        );

        if (confirmacion == JOptionPane.YES_OPTION) {

            if (productoDAO.eliminar(id)) {

                vista.mostrarMensaje("Producto eliminado correctamente.");

                cargarProductos();
                limpiarFormulario();

            } else {

                vista.mostrarMensaje("No fue posible eliminar el producto.");
            }
        }
    }

    private void venderProducto() {

        int fila = vista.getTablaProductos().getSelectedRow();

        if (fila == -1) {
            vista.mostrarMensaje("Seleccione el producto que desea vender.");
            return;
        }

        DefaultTableModel m = vista.getModeloTabla();

        int id = Integer.parseInt(m.getValueAt(fila, 0).toString());
        String nombre = m.getValueAt(fila, 2).toString();
        int stock = Integer.parseInt(m.getValueAt(fila, 5).toString());

        if (stock <= 0) {
            vista.mostrarMensaje("Este producto no tiene unidades disponibles.");
            return;
        }

        String texto = JOptionPane.showInputDialog(
                vista,
                "Producto: " + nombre + "\nDisponible: " + stock
                        + " unidades\n\n¿Cuántas unidades vende?",
                "Registrar venta",
                JOptionPane.QUESTION_MESSAGE
        );

        if (texto == null) {
            return;
        }

        int cantidad;

        try {
            cantidad = Integer.parseInt(texto.trim());
        } catch (NumberFormatException e) {
            vista.mostrarMensaje("Ingrese un número entero válido.");
            return;
        }

        if (cantidad <= 0) {
            vista.mostrarMensaje("La cantidad debe ser mayor que cero.");
            return;
        }

        try {
            double total = ventaDAO.registrarVenta(id, cantidad, vista.getNombreUsuario());

            int restante = stock - cantidad;

            cargarProductos();
            limpiarFormulario();

            String aviso = restante <= 5
                    ? "\n\n¡Atención! Quedan solo " + restante + " unidades."
                    : "";

            vista.mostrarMensaje("Venta registrada.\nTotal: "
                    + String.format(Locale.forLanguageTag("es-CO"), "$ %,.0f", total)
                    + "\nUnidades restantes: " + restante + aviso);

        } catch (Exception e) {
            vista.mostrarMensaje(e.getMessage());
        }
    }

    private Producto obtenerProductoFormulario() {

        String codigo = vista.getTxtCodigo().getText().trim();
        String nombre = vista.getTxtNombre().getText().trim();
        String categoria = vista.getTxtCategoria().getText().trim();
        String precioTexto = vista.getTxtPrecio().getText().trim();
        String stockTexto = vista.getTxtStock().getText().trim();
        String descripcion = vista.getTxtDescripcion().getText().trim();

        if (codigo.isEmpty()
                || nombre.isEmpty()
                || categoria.isEmpty()
                || precioTexto.isEmpty()
                || stockTexto.isEmpty()) {

            vista.mostrarMensaje("Complete todos los campos obligatorios.");

            return null;
        }

        double precio;
        int stock;

        try {

            precio = Double.parseDouble(precioTexto);
            stock = Integer.parseInt(stockTexto);

        } catch (NumberFormatException e) {

            vista.mostrarMensaje("Precio y stock deben ser números válidos.");

            return null;
        }

        if (precio < 0 || stock < 0) {

            vista.mostrarMensaje("Precio y stock no pueden ser negativos.");

            return null;
        }

        Producto producto = new Producto();

        producto.setCodigo(codigo);
        producto.setNombre(nombre);
        producto.setCategoria(categoria);
        producto.setPrecio(precio);
        producto.setStock(stock);
        producto.setDescripcion(descripcion);
        producto.setEstado(1);

        return producto;
    }

    private void cargarSeleccion() {

        int fila = vista.getTablaProductos().getSelectedRow();

        if (fila == -1) {
            return;
        }

        mostrarInfoProducto(fila);

        DefaultTableModel m = vista.getModeloTabla();

        vista.getTxtId().setText(m.getValueAt(fila, 0).toString());
        vista.getTxtCodigo().setText(m.getValueAt(fila, 1).toString());
        vista.getTxtNombre().setText(m.getValueAt(fila, 2).toString());
        vista.getTxtCategoria().setText(m.getValueAt(fila, 3).toString());
        vista.getTxtPrecio().setText(m.getValueAt(fila, 4).toString());
        vista.getTxtStock().setText(m.getValueAt(fila, 5).toString());

        Object descripcion = m.getValueAt(fila, 6);

        vista.getTxtDescripcion().setText(
                descripcion == null ? "" : descripcion.toString());
    }

    private void mostrarInfoProducto(int fila) {

        DefaultTableModel m = vista.getModeloTabla();

        String nombre = m.getValueAt(fila, 2).toString();
        String categoria = m.getValueAt(fila, 3).toString();
        int stock = Integer.parseInt(m.getValueAt(fila, 5).toString());

        int productosCategoria = 0;
        int unidadesCategoria = 0;

        for (int i = 0; i < m.getRowCount(); i++) {
            if (m.getValueAt(i, 3).toString().equalsIgnoreCase(categoria)) {
                productosCategoria++;
                unidadesCategoria += Integer.parseInt(m.getValueAt(i, 5).toString());
            }
        }

        String aviso = stock <= 5 ? "  (¡Stock bajo!)" : "";

        vista.mostrarInfo(nombre + ": " + stock + " unidades" + aviso
                + "  |  " + categoria + ": " + productosCategoria
                + " productos, " + unidadesCategoria + " unidades");
    }

    private void mostrarResumenGeneral() {

        DefaultTableModel m = vista.getModeloTabla();
        int unidades = 0;

        for (int i = 0; i < m.getRowCount(); i++) {
            unidades += Integer.parseInt(m.getValueAt(i, 5).toString());
        }

        vista.mostrarInfo("Total: " + m.getRowCount() + " productos, "
                + unidades + " unidades en inventario");
    }

    private void limpiarFormulario() {

        vista.getTxtId().setText("");
        vista.getTxtCodigo().setText("");
        vista.getTxtNombre().setText("");
        vista.getTxtCategoria().setText("");
        vista.getTxtPrecio().setText("");
        vista.getTxtStock().setText("");
        vista.getTxtDescripcion().setText("");

        vista.getTablaProductos().clearSelection();

        mostrarResumenGeneral();
    }
}
